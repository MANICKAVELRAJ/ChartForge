import { Injectable } from '@angular/core';
import {
  Chart,
  registerables,
  ChartConfiguration,
  ChartDataset,
  TooltipItem
} from 'chart.js/auto';

Chart.register(...registerables);

export interface ChartItem {
  id: number;
  name: string;
  type: string;
  image?: string;
  x?: number;
  y?: number;
  zIndex?: number;
  width?: number;
  height?: number;
  isXYEnabled?: boolean;
  tableId?: number;
  tableName?: string;
  fields?: string[];
  data?: any[];
  valueField?: string;
  xField?: string;
  yField?: string;
  xFieldId?: number;
  yFieldId?: number;
  xFieldValue?: string;
  yFieldValue?: string;
  shortName?: string;
  rField?: string;  // Bubble chart radius field / Timeline end date
  containerId?: string;
}

const FONT_FAMILY = "'Inter', 'Roboto', sans-serif";
const COLOR_TITLE = '#1a237e';
const COLOR_LABEL = '#546e7a';
const COLOR_GRID = '#eceff1';
const COLOR_AXIS = '#90a4ae';

const PALETTE = [
  '#1a73e8', '#34a853', '#fbbc05', '#ea4335',
  '#46bdc6', '#ff6d01', '#673ab7', '#9c27b0',
  '#0097a7', '#795548', '#607d8b'
];

// ── Speedometer zone colours (used in gauge) ─────────────────────────
const ZONE_COLORS = {
  critical: '#ea4335',   // 0 – 25 %
  low: '#ff6d01',   // 25 – 50 %
  moderate: '#fbbc05',   // 50 – 75 %
  good: '#34a853',   // 75 – 90 %
  excellent: '#1a73e8',   // 90 – 100 %
};

function zoneColor(pct: number): string {
  if (pct >= 0.90) return ZONE_COLORS.excellent;
  if (pct >= 0.75) return ZONE_COLORS.good;
  if (pct >= 0.50) return ZONE_COLORS.moderate;
  if (pct >= 0.25) return ZONE_COLORS.low;
  return ZONE_COLORS.critical;
}

function zoneLabel(pct: number): string {
  if (pct >= 0.90) return 'Excellent';
  if (pct >= 0.75) return 'Good';
  if (pct >= 0.50) return 'Moderate';
  if (pct >= 0.25) return 'Low';
  return 'Critical';
}

/* ─────────────────────────── shared builders ──────────────────────── */
function buildTooltip() {
  return {
    enabled: true,
    backgroundColor: 'rgba(26,35,126,0.92)',
    titleColor: '#fff',
    bodyColor: '#e8eaf6',
    borderColor: '#3949ab',
    borderWidth: 1,
    padding: 10,
    cornerRadius: 8,
    titleFont: { family: FONT_FAMILY, size: 12, weight: 'bold' as const },
    bodyFont: { family: FONT_FAMILY, size: 11 },
    callbacks: {
      label: (ctx: TooltipItem<any>) => {
        const v = ctx.parsed?.y ?? ctx.parsed?.r ?? ctx.formattedValue;
        return `  ${ctx.dataset.label ?? 'Value'}: ${v}`;
      }
    }
  };
}

function buildLegend(show = false) {
  return {
    display: show,
    position: 'top' as const,
    labels: {
      font: { family: FONT_FAMILY, size: 11 },
      color: COLOR_LABEL,
      boxWidth: 12,
      padding: 16,
      usePointStyle: true
    }
  };
}

function buildTitle(text: string) {
  return {
    display: true,
    text,
    color: COLOR_TITLE,
    font: { family: FONT_FAMILY, size: 14, weight: 'bold' as const },
    padding: { top: 8, bottom: 10 }
  };
}

function buildLinearAxis(label: string, stacked = false) {
  return {
    stacked,
    beginAtZero: true,
    border: { color: COLOR_AXIS },
    grid: { color: COLOR_GRID, lineWidth: 1 },
    ticks: {
      color: COLOR_LABEL,
      font: { family: FONT_FAMILY, size: 11 },
      maxTicksLimit: 8,
      padding: 4,
      callback: (v: any) => (Number.isInteger(v) ? v : +v.toFixed(2))
    },
    title: {
      display: !!label,
      text: label,
      color: COLOR_TITLE,
      font: { family: FONT_FAMILY, size: 12, weight: 'bold' as const },
      padding: { top: 4, bottom: 4 }
    }
  };
}

function buildCategoryAxis(label: string, stacked = false, totalItems = 0) {
  // Dynamic font size: shrink when many items
  const fontSize = totalItems > 20 ? 9 : totalItems > 12 ? 10 : 11;
  // Max label length before truncation
  const maxLen = totalItems > 15 ? 10 : 16;
  return {
    stacked,
    border: { color: COLOR_AXIS },
    grid: { display: false },
    ticks: {
      color: COLOR_LABEL,
      font: { family: FONT_FAMILY, size: fontSize },
      maxRotation: totalItems > 10 ? 45 : 30,
      minRotation: totalItems > 10 ? 30 : 0,
      autoSkip: false,          // ← Never skip labels — show all
      padding: 4,
      callback: function (this: any, value: any, index: number) {
        // `this` is the axis scale — use getLabelForValue to get the actual text
        const lbl = String((this as any).getLabelForValue ? (this as any).getLabelForValue(index) : value);
        return lbl.length > maxLen ? lbl.slice(0, maxLen - 1) + '…' : lbl;
      }
    },
    title: {
      display: !!label,
      text: label,
      color: COLOR_TITLE,
      font: { family: FONT_FAMILY, size: 12, weight: 'bold' as const },
      padding: { top: 4, bottom: 4 }
    }
  };
}

function baseOptions(itemName: string): any {
  return {
    responsive: true,
    maintainAspectRatio: false,
    animation: { duration: 400, easing: 'easeOutQuart' },
    layout: { padding: { top: 4, right: 12, bottom: 4, left: 4 } },
    plugins: {
      title: buildTitle(itemName),
      legend: buildLegend(false),
      tooltip: buildTooltip()
    }
  };
}

/* ══════════════════════════════════════════════════════════════════════
   ChartGenService
   ══════════════════════════════════════════════════════════════════════ */
@Injectable({ providedIn: 'root' })
export class ChartGenService {

  constructor() { }

  renderChart(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    let cfg: ChartConfiguration;

    switch (item.type) {
      case 'bar': cfg = this.barConfig(item); break;
      case 'column': cfg = this.columnConfig(item); break;
      case 'pie': cfg = this.pieConfig(item); break;
      case 'stackedBar': cfg = this.stackedBarConfig(item); break;
      case 'stackedColumn': cfg = this.stackedColumnConfig(item); break;
      case 'doughnut': cfg = this.doughnutConfig(item); break;
      case 'bubble': cfg = this.bubbleConfig(item); break;
      case 'gauge': return this.renderGauge(item, canvas);
      case 'progressBar': cfg = this.progressBarConfig(item); break;
      case 'timeline': return this.renderTimeline(item, canvas);
      default: return null;
    }

    return new Chart(ctx, cfg);
  }

  // ─── BAR ────────────────────────────────────────────────────────────
  private barConfig(item: ChartItem): ChartConfiguration {
    const field = item.yField || '';
    const { labels, values, total } = this.countData(item, field);
    return {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: field || 'Count',
          data: values,
          backgroundColor: PALETTE[0] + 'cc',
          borderColor: PALETTE[0],
          borderWidth: 1,
          borderRadius: { topRight: 5, bottomRight: 5 },
          borderSkipped: 'start',
          barPercentage: 0.7,
          categoryPercentage: 0.8
        }]
      },
      options: {
        ...baseOptions(item.name),
        indexAxis: 'y',
        scales: {
          x: buildLinearAxis('Count'),
          y: buildCategoryAxis(field, false, total)
        },
        plugins: {
          ...baseOptions(item.name).plugins,
          tooltip: {
            ...buildTooltip(),
            callbacks: {
              title: (items: TooltipItem<any>[]) => labels[items[0].dataIndex] ?? '',
              label: (ctx: TooltipItem<any>) => `  Count: ${ctx.parsed.x}`
            }
          }
        }
      } as any
    };
  }

  // ─── COLUMN ─────────────────────────────────────────────────────────
  private columnConfig(item: ChartItem): ChartConfiguration {
    const field = item.xField || '';
    const { labels, values, total } = this.countData(item, field);
    return {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: field || 'Count',
          data: values,
          backgroundColor: PALETTE[0] + 'cc',
          borderColor: PALETTE[0],
          borderWidth: 1,
          borderRadius: { topLeft: 5, topRight: 5 },
          barPercentage: 0.7,
          categoryPercentage: 0.8
        }]
      },
      options: {
        ...baseOptions(item.name),
        scales: {
          x: buildCategoryAxis(field, false, total),
          y: buildLinearAxis('Count')
        },
        plugins: {
          ...baseOptions(item.name).plugins,
          tooltip: {
            ...buildTooltip(),
            callbacks: {
              title: (items: TooltipItem<any>[]) => labels[items[0].dataIndex] ?? '',
              label: (ctx: TooltipItem<any>) => `  Count: ${ctx.parsed.y}`
            }
          }
        }
      } as any
    };
  }

  // ─── PIE ────────────────────────────────────────────────────────────
  private pieConfig(item: ChartItem): ChartConfiguration {
    const { labels, values } = this.xyData(item);
    // For legend: truncate only display, show full in tooltip
    const maxLegendLen = 14;
    const truncLabel = (s: string) => s.length > maxLegendLen ? s.slice(0, maxLegendLen - 1) + '…' : s;
    return {
      type: 'pie',
      data: {
        labels: labels.map(truncLabel),
        datasets: [{
          data: values,
          backgroundColor: PALETTE.map(c => c + 'dd'),
          borderColor: '#fff',
          borderWidth: 2,
          hoverOffset: 6
        }]
      },
      options: {
        ...baseOptions(item.name),
        plugins: {
          title: buildTitle(item.name),
          legend: {
            display: true, position: 'right' as const,
            labels: {
              font: { family: FONT_FAMILY, size: 11 }, color: COLOR_LABEL,
              boxWidth: 12, padding: 10, usePointStyle: true
            }
          },
          tooltip: {
            ...buildTooltip(), callbacks: {
              // Show FULL label in tooltip even if legend is truncated
              title: (items: TooltipItem<'pie'>[]) => labels[items[0].dataIndex] ?? '',
              label: (ctx: TooltipItem<'pie'>) => {
                const total = (ctx.dataset.data as number[]).reduce((a, b) => a + b, 0);
                const pct = total ? ((ctx.parsed / total) * 100).toFixed(1) : '0';
                return `  ${labels[ctx.dataIndex]}: ${ctx.parsed} (${pct}%)`;
              }
            }
          }
        }
      } as any
    };
  }

  // ─── STACKED BAR ────────────────────────────────────────────────────
  private stackedBarConfig(item: ChartItem): ChartConfiguration {
    const catField = item.yField || '';
    const groupField = item.xField || '';
    const { labels, datasets } = this.stackedData(item, catField, groupField);
    return {
      type: 'bar',
      data: { labels, datasets },
      options: {
        ...baseOptions(item.name),
        indexAxis: 'y',
        plugins: { ...baseOptions(item.name).plugins, legend: buildLegend(datasets.length > 1) },
        scales: {
          x: { ...buildLinearAxis('Count'), stacked: true },
          y: { ...buildCategoryAxis(catField), stacked: true }
        }
      } as any
    };
  }

  // ─── STACKED COLUMN ─────────────────────────────────────────────────
  private stackedColumnConfig(item: ChartItem): ChartConfiguration {
    const catField = item.xField || '';
    const groupField = item.yField || '';
    const { labels, datasets } = this.stackedData(item, catField, groupField);
    return {
      type: 'bar',
      data: { labels, datasets },
      options: {
        ...baseOptions(item.name),
        indexAxis: 'x',
        plugins: { ...baseOptions(item.name).plugins, legend: buildLegend(datasets.length > 1) },
        scales: {
          x: { ...buildCategoryAxis(catField), stacked: true },
          y: { ...buildLinearAxis('Count'), stacked: true }
        }
      } as any
    };
  }

  // ─── DOUGHNUT ───────────────────────────────────────────────────────
  private doughnutConfig(item: ChartItem): ChartConfiguration {
    const { labels, values } = this.xyData(item);
    const maxLegendLen = 14;
    const truncLabel = (s: string) => s.length > maxLegendLen ? s.slice(0, maxLegendLen - 1) + '…' : s;
    return {
      type: 'doughnut',
      data: {
        labels: labels.map(truncLabel),
        datasets: [{
          data: values,
          backgroundColor: PALETTE.map(c => c + 'dd'),
          borderColor: '#fff',
          borderWidth: 2,
          hoverOffset: 8
        }]
      },
      options: {
        ...baseOptions(item.name),
        cutout: '60%',
        plugins: {
          title: buildTitle(item.name),
          legend: {
            display: true, position: 'right' as const,
            labels: {
              font: { family: FONT_FAMILY, size: 11 }, color: COLOR_LABEL,
              boxWidth: 12, padding: 10, usePointStyle: true
            }
          },
          tooltip: {
            ...buildTooltip(), callbacks: {
              title: (items: TooltipItem<'doughnut'>[]) => labels[items[0].dataIndex] ?? '',
              label: (ctx: TooltipItem<'doughnut'>) => {
                const total = (ctx.dataset.data as number[]).reduce((a, b) => a + b, 0);
                const pct = total ? ((ctx.parsed / total) * 100).toFixed(1) : '0';
                return `  ${labels[ctx.dataIndex]}: ${ctx.parsed} (${pct}%)`;
              }
            }
          }
        }
      } as any
    };
  }

  // ─── BUBBLE ─────────────────────────────────────────────────────────
  private bubbleConfig(item: ChartItem): ChartConfiguration {
    const xF = item.xField || '';
    const yF = item.yField || '';
    const rF = item.rField || '';

    if (!item.data?.length) {
      return { type: 'bubble', data: { datasets: [] }, options: baseOptions(item.name) };
    }

    const rows = item.data.slice(0, 50);
    const bubbleData = rows.map(r => ({
      x: parseFloat(r[xF]) || 0,
      y: parseFloat(r[yF]) || 0,
      r: rF ? Math.min(Math.max(parseFloat(r[rF]) || 8, 4), 30) : 8
    }));

    return {
      type: 'bubble',
      data: {
        datasets: [{
          label: item.name,
          data: bubbleData,
          backgroundColor: PALETTE.map(c => c + '99'),
          borderColor: PALETTE,
          borderWidth: 1.5,
          hoverBorderWidth: 2.5
        }]
      },
      options: {
        ...baseOptions(item.name),
        plugins: {
          title: buildTitle(item.name),
          legend: buildLegend(false),
          tooltip: {
            ...buildTooltip(),
            callbacks: {
              label: (ctx: TooltipItem<'bubble'>) => {
                const d = ctx.raw as { x: number; y: number; r: number };
                return [
                  `  X (${xF}): ${d.x}`,
                  `  Y (${yF}): ${d.y}`,
                  rF ? `  R (${rF}): ${d.r}` : `  Radius: ${d.r}`
                ];
              }
            }
          }
        },
        scales: {
          x: buildLinearAxis(xF || 'X'),
          y: buildLinearAxis(yF || 'Y')
        }
      } as any
    };
  }

  /* ════════════════════════════════════════════════════════════════════
     GAUGE / SPEEDOMETER  — fully rewritten
     ════════════════════════════════════════════════════════════════════
     X Field  → progress / achieved value (summed across all rows)
     Y Field  → target / maximum value    (summed across all rows)

     Visual:
       • 210° arc split into 5 colour zones (critical → excellent)
       • Speed-style tick marks every 5 % (major every 25 %)
       • Animated needle with tapered shape
       • Hub cap with inner ring
       • Large centre % badge + raw value label
       • Zone label badge below the arc
  ═════════════════════════════════════════════════════════════════════ */
  private renderGauge(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    const valueField = item.xField || '';
    const targetField = item.yField || '';
    const rows = item.data ?? [];

    // ── Aggregate progress & target ───────────────────────────────────
    let progress = 0;
    let target = 100;
    if (rows.length && valueField)
      progress = rows.reduce((s: number, r: any) => s + (parseFloat(r[valueField]) || 0), 0);
    if (rows.length && targetField)
      target = rows.reduce((s: number, r: any) => s + (parseFloat(r[targetField]) || 0), 0);
    if (target <= 0) target = 100;

    const pct = Math.min(Math.max(progress / target, 0), 1); // clamp 0–1

    // ── Arc geometry ──────────────────────────────────────────────────
    // Arc starts at 210° (lower-left) and sweeps 210° to 330° (lower-right)
    // Using canvas angles: 0° = 3 o'clock, clockwise positive
    const START_DEG = 210;   // degrees
    const SWEEP_DEG = 210;   // total arc span (120° gap at bottom)
    const toRad = (d: number) => (d * Math.PI) / 180;

    const startAngle = toRad(START_DEG);          // start of arc (lower-left)
    const endAngle = toRad(START_DEG + SWEEP_DEG); // end of arc (lower-right)

    // ── Zone boundaries (as fraction 0-1 → angle) ────────────────────
    const zones: Array<{ from: number; to: number; color: string; label: string }> = [
      { from: 0.00, to: 0.25, color: ZONE_COLORS.critical, label: 'Critical' },
      { from: 0.25, to: 0.50, color: ZONE_COLORS.low, label: 'Low' },
      { from: 0.50, to: 0.75, color: ZONE_COLORS.moderate, label: 'Moderate' },
      { from: 0.75, to: 0.90, color: ZONE_COLORS.good, label: 'Good' },
      { from: 0.90, to: 1.00, color: ZONE_COLORS.excellent, label: 'Excellent' },
    ];

    const needleColor = zoneColor(pct);
    const statusLabel = zoneLabel(pct);
    const fmt = (n: number) => n >= 1_000_000 ? (n / 1_000_000).toFixed(1) + 'M'
      : n >= 1000 ? (n / 1000).toFixed(1) + 'k'
        : n % 1 === 0 ? String(n)
          : n.toFixed(1);

    // ── Plugin — draws everything on top of the invisible doughnut ────
    // ── Animation state for needle sweep ─────────────────────────────────
    let gaugeRafId: number | null = null;
    const GAUGE_ANIM_MS = 1500;
    const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);

    const drawGaugeFrame = (c: CanvasRenderingContext2D, width: number, height: number, ap: number) => {
      const cx = width / 2;
      const cy = height * 0.58;
      const outerR = Math.min(cx, cy) * 0.80;
      const trackW = outerR * 0.22;
      const innerR = outerR - trackW;

      const aNeedleColor = zoneColor(ap);
      const aStatusLabel = zoneLabel(ap);

      c.save();
      c.clearRect(0, 0, width, height);

      // 1. Background track
      c.beginPath();
      c.arc(cx, cy, outerR, startAngle, endAngle);
      c.strokeStyle = '#e8eaf6';
      c.lineWidth = trackW;
      c.lineCap = 'round';
      c.stroke();

      // 2. Zone colour arcs
      zones.forEach(zone => {
        const a1 = startAngle + toRad(SWEEP_DEG * zone.from);
        const a2 = startAngle + toRad(SWEEP_DEG * zone.to);
        c.beginPath();
        c.arc(cx, cy, outerR - trackW / 2, a1, a2);
        c.strokeStyle = zone.color + 'aa';
        c.lineWidth = trackW;
        c.lineCap = 'butt';
        c.stroke();
      });

      // 3. Filled progress arc up to animated position
      const progressAngle = startAngle + toRad(SWEEP_DEG * ap);
      const grad = c.createLinearGradient(
        cx + Math.cos(startAngle) * outerR, cy + Math.sin(startAngle) * outerR,
        cx + Math.cos(progressAngle) * outerR, cy + Math.sin(progressAngle) * outerR
      );
      grad.addColorStop(0, ZONE_COLORS.critical + 'ff');
      grad.addColorStop(0.5, ZONE_COLORS.moderate + 'ff');
      grad.addColorStop(1, aNeedleColor + 'ff');
      c.beginPath();
      c.arc(cx, cy, outerR - trackW / 2, startAngle, progressAngle);
      c.strokeStyle = grad;
      c.lineWidth = trackW;
      c.lineCap = 'round';
      c.stroke();

      // 4. Tick marks
      const TOTAL_TICKS = 40;
      for (let i = 0; i <= TOTAL_TICKS; i++) {
        const t = i / TOTAL_TICKS;
        const angle = startAngle + toRad(SWEEP_DEG * t);
        const isMajor = i % 10 === 0;
        const isMid = i % 5 === 0;
        const tickOuter = outerR + (isMajor ? 10 : isMid ? 6 : 3);
        const tickInner = outerR + 1;
        const tc = Math.cos(angle), ts = Math.sin(angle);
        c.beginPath();
        c.moveTo(cx + tc * tickInner, cy + ts * tickInner);
        c.lineTo(cx + tc * tickOuter, cy + ts * tickOuter);
        c.strokeStyle = isMajor ? '#455a64' : '#b0bec5';
        c.lineWidth = isMajor ? 2 : 1;
        c.stroke();
        if (isMajor) {
          const labelR = outerR + 22;
          c.font = `bold 9px ${FONT_FAMILY}`;
          c.fillStyle = '#546e7a';
          c.textAlign = 'center';
          c.textBaseline = 'middle';
          c.fillText(`${Math.round(t * 100)}%`, cx + tc * labelR, cy + ts * labelR);
        }
      }

      // 5. Zone separator lines
      [0.25, 0.50, 0.75, 0.90].forEach(boundary => {
        const angle = startAngle + toRad(SWEEP_DEG * boundary);
        const sc = Math.cos(angle), ss = Math.sin(angle);
        c.beginPath();
        c.moveTo(cx + sc * (innerR - 2), cy + ss * (innerR - 2));
        c.lineTo(cx + sc * (outerR + 2), cy + ss * (outerR + 2));
        c.strokeStyle = '#ffffffcc';
        c.lineWidth = 2;
        c.stroke();
      });

      // 6. Needle at animated angle
      const needleAngle = startAngle + toRad(SWEEP_DEG * ap);
      const needleLength = innerR * 0.88;
      const needleBase = 10;
      const nc = Math.cos(needleAngle), ns = Math.sin(needleAngle);
      const perpCos = Math.cos(needleAngle + Math.PI / 2);
      const perpSin = Math.sin(needleAngle + Math.PI / 2);
      c.shadowColor = 'rgba(0,0,0,0.25)';
      c.shadowBlur = 8; c.shadowOffsetX = 2; c.shadowOffsetY = 2;
      c.beginPath();
      c.moveTo(cx + nc * needleLength, cy + ns * needleLength);
      c.lineTo(cx + perpCos * needleBase - nc * 12, cy + perpSin * needleBase - ns * 12);
      c.lineTo(cx - nc * (needleBase * 0.6), cy - ns * (needleBase * 0.6));
      c.lineTo(cx - perpCos * needleBase - nc * 12, cy - perpSin * needleBase - ns * 12);
      c.closePath();
      const nGrad = c.createLinearGradient(cx - nc * 12, cy - ns * 12, cx + nc * needleLength, cy + ns * needleLength);
      nGrad.addColorStop(0, '#1a237e');
      nGrad.addColorStop(0.5, aNeedleColor);
      nGrad.addColorStop(1, '#ffffff88');
      c.fillStyle = nGrad; c.fill();
      c.shadowBlur = 0; c.shadowOffsetX = 0; c.shadowOffsetY = 0;

      // 7. Hub cap
      c.beginPath(); c.arc(cx, cy, 16, 0, Math.PI * 2);
      const hubGrad = c.createRadialGradient(cx - 3, cy - 3, 2, cx, cy, 16);
      hubGrad.addColorStop(0, '#546e7a'); hubGrad.addColorStop(1, '#1a237e');
      c.fillStyle = hubGrad; c.fill();
      c.beginPath(); c.arc(cx, cy, 10, 0, Math.PI * 2); c.fillStyle = '#eceff1'; c.fill();
      c.beginPath(); c.arc(cx, cy, 4, 0, Math.PI * 2); c.fillStyle = aNeedleColor; c.fill();

      // 8. Centre percentage label (shows animated value)
      const labelY = cy + innerR * 0.38;
      c.font = `bold 28px ${FONT_FAMILY}`; c.fillStyle = aNeedleColor;
      c.textAlign = 'center'; c.textBaseline = 'alphabetic';
      c.fillText(`${(ap * 100).toFixed(1)}%`, cx, labelY);

      // 9. Progress / target values
      c.font = `12px ${FONT_FAMILY}`; c.fillStyle = '#546e7a';
      c.fillText(`${fmt(progress)} / ${fmt(target)}`, cx, labelY + 18);

      // 10. Zone status badge
      const badgeY = labelY + 40;
      const badgePad = { x: 14, y: 5 };
      c.font = `bold 11px ${FONT_FAMILY}`;
      const textW = c.measureText(aStatusLabel).width;
      const bx = cx - textW / 2 - badgePad.x;
      const by = badgeY - 14;
      const bw = textW + badgePad.x * 2;
      const bh = 22;
      c.beginPath(); c.roundRect(bx, by, bw, bh, 11);
      c.fillStyle = aNeedleColor + '22'; c.fill();
      c.strokeStyle = aNeedleColor + '88'; c.lineWidth = 1.5; c.stroke();
      c.fillStyle = aNeedleColor; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText(aStatusLabel, cx, by + bh / 2);

      // 11. Chart title
      c.font = `bold 13px ${FONT_FAMILY}`; c.fillStyle = COLOR_TITLE;
      c.textBaseline = 'top'; c.fillText(item.name, cx, 10);

      // 12. Field labels
      if (valueField || targetField) {
        c.font = `10px ${FONT_FAMILY}`; c.fillStyle = COLOR_LABEL;
        c.fillText(`${valueField || '\u2014'} \u00f7 ${targetField || '\u2014'}`, cx, 28);
      }
      c.restore();
    };

    const speedometerPlugin = {
      id: 'speedometerPlugin',
      afterDatasetsDraw(chart: any) {
        const { ctx: c, width, height } = chart;
        // Cancel any running animation before starting a fresh sweep
        if (gaugeRafId !== null) { cancelAnimationFrame(gaugeRafId); gaugeRafId = null; }
        const startTime = performance.now();
        const animate = (now: number) => {
          const elapsed = now - startTime;
          const t = Math.min(elapsed / GAUGE_ANIM_MS, 1);
          const ap = easeOutCubic(t) * pct;
          drawGaugeFrame(c, width, height, ap);
          if (t < 1) {
            gaugeRafId = requestAnimationFrame(animate);
          } else {
            gaugeRafId = null;
          }
        };
        gaugeRafId = requestAnimationFrame(animate);
      }
    };

    return new Chart(ctx, {
      type: 'doughnut',
      data: { datasets: [] },
      options: { responsive: true, maintainAspectRatio: false } as any,
      plugins: [speedometerPlugin]
    } as any);
  }

  // ─── PROGRESS BAR ───────────────────────────────────────────────────
  private progressBarConfig(item: ChartItem): ChartConfiguration {
    const labelField = item.xField || '';
    const completedField = item.yField || '';
    const totalField = item.rField || '';

    if (!item.data?.length) {
      return {
        type: 'bar',
        data: { labels: [], datasets: [] },
        options: { ...baseOptions(item.name), indexAxis: 'y' } as any
      };
    }

    const rows = item.data.slice(0, 20);
    const labels = rows.map(r => String(r[labelField] ?? ''));
    const completed = rows.map(r => { const v = parseFloat(r[completedField]); return isNaN(v) ? 0 : v; });
    const totals = rows.map(r => { const v = parseFloat(r[totalField]); return isNaN(v) || v <= 0 ? 100 : v; });
    const pcts = completed.map((c, i) => Math.min((c / totals[i]) * 100, 100));
    const remaining = pcts.map(p => Math.max(100 - p, 0));

    const barColors = pcts.map(p =>
      p >= 90 ? '#34a853ee' :
        p >= 75 ? '#fbbc05ee' :
          p >= 50 ? '#ff6d01ee' :
            '#ea4335ee'
    );

    const pctLabelPlugin = {
      id: 'progressBarLabels',
      afterDatasetsDraw(chart: any) {
        const { ctx } = chart;
        chart.getDatasetMeta(0).data.forEach((bar: any, i: number) => {
          const fmt = (n: number) => n >= 1000 ? (n / 1000).toFixed(1) + 'k' : n.toFixed(0);
          ctx.save();
          ctx.font = `bold 11px ${FONT_FAMILY}`;
          ctx.fillStyle = '#1a237e';
          ctx.textAlign = 'left';
          ctx.textBaseline = 'middle';
          ctx.fillText(
            `${pcts[i].toFixed(1)}%  (${fmt(completed[i])} / ${fmt(totals[i])})`,
            bar.x + 6, bar.y
          );
          ctx.restore();
        });
      }
    };

    return {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: 'Completed',
            data: pcts,
            backgroundColor: barColors,
            borderColor: barColors.map((c: string) => c.slice(0, 7)),
            borderWidth: 0,
            borderRadius: { topRight: 6, bottomRight: 6 },
            borderSkipped: false,
            barPercentage: 0.65,
            categoryPercentage: 0.85
          },
          {
            label: 'Remaining',
            data: remaining,
            backgroundColor: '#e0e0e055',
            borderColor: '#e0e0e0',
            borderWidth: 0,
            borderRadius: { topRight: 6, bottomRight: 6 },
            borderSkipped: false,
            barPercentage: 0.65,
            categoryPercentage: 0.85
          }
        ]
      },
      options: {
        ...baseOptions(item.name),
        indexAxis: 'y',
        layout: { padding: { top: 4, right: 120, bottom: 4, left: 4 } },
        plugins: {
          title: buildTitle(item.name),
          legend: { display: false },
          tooltip: {
            enabled: true,
            backgroundColor: 'rgba(26,35,126,0.92)',
            titleColor: '#fff',
            bodyColor: '#e8eaf6',
            borderColor: '#3949ab',
            borderWidth: 1,
            padding: 10,
            cornerRadius: 8,
            callbacks: {
              label: (ctx: TooltipItem<any>) => {
                const i = ctx.dataIndex;
                if (ctx.datasetIndex === 0)
                  return `  Completed: ${pcts[i].toFixed(1)}%  (${completed[i]} / ${totals[i]})`;
                return `  Remaining: ${remaining[i].toFixed(1)}%`;
              }
            }
          }
        },
        scales: {
          x: {
            stacked: true, min: 0, max: 100, beginAtZero: true,
            border: { color: COLOR_AXIS },
            grid: { color: COLOR_GRID, lineWidth: 1 },
            ticks: {
              color: COLOR_LABEL,
              font: { family: FONT_FAMILY, size: 11 },
              callback: (v: any) => v + '%'
            },
            title: {
              display: true, text: 'Completion %',
              color: COLOR_TITLE,
              font: { family: FONT_FAMILY, size: 12, weight: 'bold' as const }
            }
          },
          y: {
            stacked: true,
            border: { color: COLOR_AXIS },
            grid: { display: false },
            ticks: { color: COLOR_LABEL, font: { family: FONT_FAMILY, size: 11 }, padding: 4 }
          }
        }
      } as any,
      plugins: [pctLabelPlugin]
    } as any;
  }

  // ─── TIMELINE ───────────────────────────────────────────────────────
  private renderTimeline(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    const labelField = item.xField || '';  // event / task name
    const startField = item.yField || '';  // start date
    const endField = item.rField || '';  // end date

    if (!item.data?.length) return null;

    const rows = item.data.slice(0, 20);

    const parseDate = (v: any): number => {
      if (!v) return Date.now();
      if (typeof v === 'number') return v;
      const d = new Date(v);
      return isNaN(d.getTime()) ? Date.now() : d.getTime();
    };

    const events = rows.map((r, i) => ({
      label: String(r[labelField] ?? `Event ${i + 1}`),
      start: parseDate(r[startField]),
      end: parseDate(r[endField] || r[startField]),
      color: PALETTE[i % PALETTE.length]
    }));

    const allTimes = events.flatMap(e => [e.start, e.end]);
    const minTime = Math.min(...allTimes);
    const maxTime = Math.max(...allTimes);
    const padding = Math.max((maxTime - minTime) * 0.05, 86_400_000);

    const fmtDate = (ms: number) => {
      const d = new Date(ms);
      return `${d.getDate()} ${d.toLocaleString('default', { month: 'short' })} ${d.getFullYear()}`;
    };

    // ── Animation state for timeline bars ──────────────────────────────
    let tlRafId: number | null = null;
    const TL_ANIM_MS = 1000;  // total animation duration
    const TL_STAGGER = 90;    // ms delay per row
    const easeOutCubicTL = (t: number) => 1 - Math.pow(1 - t, 3);

    // Draws all bars; each bar's progress is based on its own staggered timeline
    const drawTimelineBars = (
      c: CanvasRenderingContext2D,
      chart: any,
      elapsed: number
    ) => {
      const { chartArea, scales } = chart;
      if (!chartArea || !scales?.x || !scales?.y) return;
      const xScale = scales.x;
      const yScale = scales.y;

      events.forEach((ev, i) => {
        // Each row starts TL_STAGGER ms after the previous one
        const rowElapsed = Math.max(0, elapsed - i * TL_STAGGER);
        const rowT = Math.min(rowElapsed / (TL_ANIM_MS * 0.75), 1);
        const rowProg = easeOutCubicTL(rowT); // 0 → 1

        const x1 = xScale.getPixelForValue(ev.start);
        const x2Max = xScale.getPixelForValue(Math.max(ev.end, ev.start + padding * 0.2));
        // Animated right edge grows from x1 → x2Max
        const x2 = x1 + (x2Max - x1) * rowProg;

        if (x2 <= x1 + 1) return; // not visible yet

        const y = yScale.getPixelForValue(i);
        const barH = Math.max(14, (yScale.height / Math.max(events.length, 1)) * 0.52);
        const r = Math.min(barH / 2, 7);

        c.save();
        // Clip so bar never spills past its final position
        c.beginPath();
        c.rect(x1, y - barH / 2 - 2, x2Max - x1 + 60, barH + 4);
        c.clip();

        c.shadowColor = 'rgba(0,0,0,0.14)';
        c.shadowBlur = 5; c.shadowOffsetY = 2;

        c.beginPath();
        c.moveTo(x1 + r, y - barH / 2);
        c.lineTo(x2 - r, y - barH / 2);
        c.quadraticCurveTo(x2, y - barH / 2, x2, y - barH / 2 + r);
        c.lineTo(x2, y + barH / 2 - r);
        c.quadraticCurveTo(x2, y + barH / 2, x2 - r, y + barH / 2);
        c.lineTo(x1 + r, y + barH / 2);
        c.quadraticCurveTo(x1, y + barH / 2, x1, y + barH / 2 - r);
        c.lineTo(x1, y - barH / 2 + r);
        c.quadraticCurveTo(x1, y - barH / 2, x1 + r, y - barH / 2);
        c.closePath();

        const grad = c.createLinearGradient(x1, 0, x2Max, 0);
        grad.addColorStop(0, ev.color + 'ff');
        grad.addColorStop(1, ev.color + '88');
        c.fillStyle = grad; c.fill();
        c.shadowBlur = 0;

        // Label — fade in once bar is wide enough
        c.font = `bold 11px ${FONT_FAMILY}`;
        const textW = c.measureText(ev.label).width;
        const barW = x2 - x1;
        if (barW > textW + 14) {
          c.globalAlpha = Math.min((barW - textW - 14) / 30, 1);
          c.fillStyle = '#ffffff'; c.textAlign = 'left'; c.textBaseline = 'middle';
          c.fillText(ev.label, x1 + 8, y);
          c.globalAlpha = 1;
        }

        // Duration label — only once bar animation is complete
        if (rowT >= 1) {
          const days = Math.round((ev.end - ev.start) / 86_400_000);
          if (days > 0) {
            c.font = `10px ${FONT_FAMILY}`; c.fillStyle = '#546e7a';
            c.textAlign = 'left'; c.textBaseline = 'middle';
            c.fillText(`${days}d`, x2Max + 5, y);
          }
        }

        // Start dot
        c.beginPath(); c.arc(x1, y, 4, 0, Math.PI * 2);
        c.fillStyle = '#ffffff'; c.fill();
        c.strokeStyle = ev.color; c.lineWidth = 2; c.stroke();

        c.restore();
      });
    };

    const timelinePlugin = {
      id: 'timelinePlugin',
      afterDatasetsDraw(chart: any) {
        const { ctx: c, chartArea } = chart;
        if (!chartArea) return;
        // Cancel any running animation
        if (tlRafId !== null) { cancelAnimationFrame(tlRafId); tlRafId = null; }

        const startTime = performance.now();
        const lastRowEndMs = TL_STAGGER * (events.length - 1) + TL_ANIM_MS * 0.75;

        const animate = (now: number) => {
          const elapsed = now - startTime;
          // Clear only the chart draw area on each frame
          c.save();
          c.clearRect(
            chartArea.left - 2, chartArea.top - 2,
            chartArea.right - chartArea.left + 70,
            chartArea.bottom - chartArea.top + 4
          );
          c.restore();
          drawTimelineBars(c, chart, elapsed);
          if (elapsed < lastRowEndMs) {
            tlRafId = requestAnimationFrame(animate);
          } else {
            tlRafId = null;
          }
        };
        tlRafId = requestAnimationFrame(animate);
      }
    };

    return new Chart(ctx, {
      type: 'scatter',
      data: {
        datasets: events.map((ev) => ({
          label: ev.label,
          data: [{ x: ev.start, y: events.indexOf(ev) }, { x: ev.end, y: events.indexOf(ev) }],
          pointRadius: 0,
          showLine: false,
          backgroundColor: 'transparent'
        }))
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 500, easing: 'easeOutQuart' },
        layout: { padding: { top: 8, right: 55, bottom: 8, left: 8 } },
        plugins: {
          title: buildTitle(item.name),
          legend: { display: false },
          tooltip: {
            enabled: true,
            backgroundColor: 'rgba(26,35,126,0.92)',
            titleColor: '#fff',
            bodyColor: '#e8eaf6',
            borderColor: '#3949ab',
            borderWidth: 1,
            padding: 10,
            cornerRadius: 8,
            callbacks: {
              title: (items: any[]) => events[items[0]?.datasetIndex]?.label ?? '',
              label: (ctx: any) => {
                const ev = events[ctx.datasetIndex];
                if (!ev) return '';
                const days = Math.round((ev.end - ev.start) / 86_400_000);
                return [
                  `  Start    : ${fmtDate(ev.start)}`,
                  `  End      : ${fmtDate(ev.end)}`,
                  `  Duration : ${days} day${days !== 1 ? 's' : ''}`
                ];
              }
            }
          }
        },
        scales: {
          x: {
            type: 'linear',
            min: minTime - padding,
            max: maxTime + padding,
            border: { color: COLOR_AXIS },
            grid: { color: COLOR_GRID, lineWidth: 1 },
            ticks: {
              color: COLOR_LABEL,
              font: { family: FONT_FAMILY, size: 10 },
              maxTicksLimit: 8,
              callback: (v: any) => fmtDate(Number(v))
            },
            title: {
              display: true, text: 'Date',
              color: COLOR_TITLE,
              font: { family: FONT_FAMILY, size: 12, weight: 'bold' as const }
            }
          },
          y: {
            type: 'linear',
            min: -0.5,
            max: events.length - 0.5,
            reverse: true,
            border: { color: COLOR_AXIS },
            grid: { display: false },
            ticks: {
              color: COLOR_LABEL,
              font: { family: FONT_FAMILY, size: 11 },
              stepSize: 1,
              callback: (v: any) => {
                const idx = Math.round(Number(v));
                return events[idx]?.label ?? '';
              }
            }
          }
        }
      } as any,
      plugins: [timelinePlugin]
    } as any);
  }

  /* ═══════════════════════════════════════════════════════════════════
     HELPERS
  ═══════════════════════════════════════════════════════════════════ */
  private countData(item: ChartItem, dimField: string) {
    if (!item.data?.length || !dimField) return { labels: [], values: [], total: 0 };
    const counts: Record<string, number> = {};
    for (const row of item.data) {
      const k = String(row[dimField] ?? 'N/A');
      counts[k] = (counts[k] ?? 0) + 1;
    }
    // Sort by count desc — NO hard slice cap; show all unique values
    const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
    return { labels: sorted.map(e => e[0]), values: sorted.map(e => e[1]), total: sorted.length };
  }

  private xyData(item: ChartItem) {
    if (!item.data?.length) return { labels: [], values: [], total: 0 };
    const xF = item.xField || '';
    const yF = item.yField || '';
    // Aggregate: group by xField, sum yField values — handles all record counts
    if (xF && yF) {
      const agg: Record<string, number> = {};
      for (const r of item.data) {
        const key = String(r[xF] ?? 'N/A');
        const val = parseFloat(r[yF]);
        agg[key] = (agg[key] ?? 0) + (isNaN(val) ? 0 : val);
      }
      const sorted = Object.entries(agg).sort((a, b) => b[1] - a[1]);
      return { labels: sorted.map(e => e[0]), values: sorted.map(e => e[1]), total: sorted.length };
    }
    // Fallback: raw rows (no field selected yet)
    const rows = item.data;
    const labels = rows.map(r => String(r[xF] ?? ''));
    const values = rows.map(r => { const v = parseFloat(r[yF]); return isNaN(v) ? 0 : v; });
    return { labels, values, total: rows.length };
  }

  private stackedData(item: ChartItem, catField: string, groupField: string) {
    if (!item.data?.length || !catField) return { labels: [], datasets: [] };
    const allCats = [...new Set(item.data.map(r => String(r[catField] ?? 'N/A')))].slice(0, 12);
    if (!groupField) {
      return {
        labels: allCats,
        datasets: [{
          label: 'Total',
          data: allCats.map(c => item.data!.filter(r => String(r[catField]) === c).length),
          backgroundColor: PALETTE[0] + 'cc',
          borderColor: PALETTE[0],
          borderWidth: 1,
          borderRadius: 4,
          barPercentage: 0.75
        }]
      };
    }
    const allGroups = [...new Set(item.data.map(r => String(r[groupField] ?? 'N/A')))].slice(0, 8);
    const datasets: ChartDataset[] = allGroups.map((g, i) => ({
      label: g,
      data: allCats.map(c =>
        item.data!.filter(r => String(r[catField]) === c && String(r[groupField]) === g).length
      ),
      backgroundColor: PALETTE[i % PALETTE.length] + 'cc',
      borderColor: PALETTE[i % PALETTE.length],
      borderWidth: 1,
      borderRadius: 3,
      barPercentage: 0.8
    } as any));
    return { labels: allCats, datasets };
  }
}