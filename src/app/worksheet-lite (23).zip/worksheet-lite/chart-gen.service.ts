import { Injectable } from '@angular/core';
import { Chart } from 'chart.js';   // chart.js@2.9.4 — default import only

/*
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  chart-gen.service.ts  —  Chart.js 2.9.4 edition                   ║
 * ║                                                                      ║
 * ║  Key differences from v4 → v2.9.4:                                  ║
 * ║  • import Chart from 'chart.js'  (no /auto, no registerables)       ║
 * ║  • horizontalBar type  (no indexAxis:'y')                            ║
 * ║  • scales: { xAxes:[…], yAxes:[…] }  (not x/y keys)                ║
 * ║  • title / legend / tooltips are TOP-LEVEL options (not plugins.*)  ║
 * ║  • tooltips callbacks receive (tooltipItem, data) not (ctx)         ║
 * ║  • cutoutPercentage  (not cutout:'62%')                              ║
 * ║  • No borderRadius on datasets                                       ║
 * ║  • No animation.delay function                                       ║
 * ║  • bar._model.x / bar._model.y  (not bar.x / bar.y)                ║
 * ║  • arc._view  (not arc.startAngle directly)                          ║
 * ║  • scale ids: 'x-axis-0' / 'y-axis-0'                               ║
 * ║  • No ctx.roundRect — use manual quadraticCurveTo path               ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */

/* ═══════════════════════════════════════════════════════════════════════
   INTERFACE
═══════════════════════════════════════════════════════════════════════ */
export interface ChartItem {
  id: number;
  name: string;
  type: string;
  image?: string;
  x?: number;
  y?: number;
  zIndex?: number;
  width?: number;
  height?: number;
  isXYEnabled?: boolean;
  tableId?: number;
  tableName?: string;
  fields?: string[];
  data?: any[];
  valueField?: string;
  xField?: string;
  yField?: string;
  xFieldId?: number;
  yFieldId?: number;
  xFieldValue?: string;
  yFieldValue?: string;
  shortName?: string;
  rField?: string;   // bubble radius / timeline end-date
}

/* ═══════════════════════════════════════════════════════════════════════
   CONSTANTS
═══════════════════════════════════════════════════════════════════════ */
const FONT_FAMILY = "'Inter', 'Roboto', sans-serif";
const COLOR_TITLE = '#1a237e';
const COLOR_LABEL = '#546e7a';
const COLOR_GRID = '#eceff1';
const COLOR_AXIS = '#90a4ae';

const PALETTE: string[] = [
  '#1a73e8', '#34a853', '#fbbc05', '#ea4335',
  '#46bdc6', '#ff6d01', '#673ab7', '#9c27b0',
  '#0097a7', '#795548', '#607d8b'
];

const ZONE_COLORS = {
  critical: '#ea4335',
  low: '#ff6d01',
  moderate: '#fbbc05',
  good: '#34a853',
  excellent: '#1a73e8',
};

/* ═══════════════════════════════════════════════════════════════════════
   ZONE HELPERS
═══════════════════════════════════════════════════════════════════════ */
function zoneColor(pct: number): string {
  if (pct >= 0.90) return ZONE_COLORS.excellent;
  if (pct >= 0.75) return ZONE_COLORS.good;
  if (pct >= 0.50) return ZONE_COLORS.moderate;
  if (pct >= 0.25) return ZONE_COLORS.low;
  return ZONE_COLORS.critical;
}
function zoneLabel(pct: number): string {
  if (pct >= 0.90) return 'Excellent';
  if (pct >= 0.75) return 'Good';
  if (pct >= 0.50) return 'Moderate';
  if (pct >= 0.25) return 'Low';
  return 'Critical';
}

/* ═══════════════════════════════════════════════════════════════════════
   CONFIG BUILDERS  —  all tuned for Chart.js 2.9.4 option structure
═══════════════════════════════════════════════════════════════════════ */

/** v2 tooltip block (lives at options.tooltips, NOT options.plugins.tooltip) */
function buildTooltips(callbacks: any = {}): any {
  return {
    enabled: true,
    backgroundColor: 'rgba(26,35,126,0.95)',
    titleFontFamily: FONT_FAMILY,
    titleFontSize: 12,
    titleFontStyle: 'bold',
    titleFontColor: '#fff',
    bodyFontFamily: FONT_FAMILY,
    bodyFontSize: 11,
    bodyFontColor: '#e8eaf6',
    borderColor: '#3949ab',
    borderWidth: 1,
    xPadding: 12,
    yPadding: 10,
    cornerRadius: 8,
    callbacks
  };
}

/** v2 legend block (lives at options.legend) */
function buildLegend(display = false, position = 'top'): any {
  return {
    display,
    position,
    labels: {
      fontFamily: FONT_FAMILY,
      fontSize: 11,
      fontColor: COLOR_LABEL,
      boxWidth: 12,
      padding: 16,
      usePointStyle: true
    }
  };
}

/** v2 title block (lives at options.title) */
function buildTitle(text: string): any {
  return {
    display: true,
    text,
    fontColor: COLOR_TITLE,
    fontFamily: FONT_FAMILY,
    fontSize: 14,
    fontStyle: 'bold',
    padding: 10
  };
}

/** v2 linear scale object (goes INSIDE xAxes[] or yAxes[]) */
function linearScale(labelText = '', stacked = false): any {
  return {
    stacked,
    ticks: {
      beginAtZero: true,
      fontColor: COLOR_LABEL,
      fontFamily: FONT_FAMILY,
      fontSize: 11,
      maxTicksLimit: 8,
      padding: 4,
      callback: (v: any) => Number.isInteger(v) ? v : +Number(v).toFixed(2)
    },
    gridLines: { color: COLOR_GRID, lineWidth: 1, zeroLineColor: COLOR_AXIS },
    scaleLabel: {
      display: !!labelText,
      labelString: labelText,
      fontColor: COLOR_TITLE,
      fontFamily: FONT_FAMILY,
      fontSize: 12,
      fontStyle: 'bold'
    }
  };
}

/** v2 category scale object (goes INSIDE xAxes[] or yAxes[]) */
function categoryScale(labelText = '', stacked = false): any {
  return {
    stacked,
    ticks: {
      fontColor: COLOR_LABEL,
      fontFamily: FONT_FAMILY,
      fontSize: 11,
      maxRotation: 35,
      minRotation: 0,
      autoSkip: true,
      maxTicksLimit: 12,
      padding: 4
    },
    gridLines: { display: false },
    scaleLabel: {
      display: !!labelText,
      labelString: labelText,
      fontColor: COLOR_TITLE,
      fontFamily: FONT_FAMILY,
      fontSize: 12,
      fontStyle: 'bold'
    }
  };
}

/** Shared base options block for v2 charts */
function baseOptions(name: string, animEasing = 'easeOutQuart'): any {
  return {
    responsive: true,
    maintainAspectRatio: false,
    animation: { duration: 900, easing: animEasing },
    layout: { padding: { top: 4, right: 12, bottom: 4, left: 4 } },
    title: buildTitle(name),
    legend: buildLegend(false),
    tooltips: buildTooltips()
  };
}

/* ═══════════════════════════════════════════════════════════════════════
   VALUE-LABEL PLUGIN
   Draws the numeric value above (vertical) or right-of (horizontal) bar.
   Uses bar._model.x / bar._model.y — the v2 way.
═══════════════════════════════════════════════════════════════════════ */
function valueLabelPlugin(horizontal: boolean): any {
  return {
    id: 'valueLabelPlugin',
    afterDatasetsDraw(chart: any) {
      const { ctx } = chart;
      chart.data.datasets.forEach((_: any, di: number) => {
        const meta = chart.getDatasetMeta(di);
        if (meta.hidden) return;
        meta.data.forEach((bar: any, i: number) => {
          const raw = chart.data.datasets[di].data[i];
          if (raw == null || raw === 0) return;
          const label = typeof raw === 'number'
            ? (raw >= 1000 ? (raw / 1000).toFixed(1) + 'k' : String(raw))
            : '';
          if (!label) return;
          const mx = bar._model.x;
          const my = bar._model.y;
          ctx.save();
          ctx.font = `bold 10px ${FONT_FAMILY}`;
          ctx.fillStyle = COLOR_TITLE;
          ctx.textBaseline = 'middle';
          if (horizontal) {
            ctx.textAlign = 'left';
            ctx.fillText(label, mx + 5, my);
          } else {
            ctx.textAlign = 'center';
            ctx.fillText(label, mx, my - 8);
          }
          ctx.restore();
        });
      });
    }
  };
}

/* ═══════════════════════════════════════════════════════════════════════
   ROUNDED RECT helper  (ctx.roundRect not in v2 / older Chrome)
═══════════════════════════════════════════════════════════════════════ */
function roundRect(ctx: CanvasRenderingContext2D,
  x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  ctx.lineTo(x + rr, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rr);
  ctx.lineTo(x, y + rr);
  ctx.quadraticCurveTo(x, y, x + rr, y);
  ctx.closePath();
}

/* ═══════════════════════════════════════════════════════════════════════
   SERVICE
═══════════════════════════════════════════════════════════════════════ */
@Injectable({ providedIn: 'root' })
export class ChartGenService {

  constructor() { }

  renderChart(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    switch (item.type) {
      case 'bar': return this.renderBar(item, canvas);
      case 'column': return this.renderColumn(item, canvas);
      case 'pie': return this.renderPie(item, canvas);
      case 'stackedBar': return this.renderStackedBar(item, canvas);
      case 'stackedColumn': return this.renderStackedColumn(item, canvas);
      case 'doughnut': return this.renderDoughnut(item, canvas);
      case 'bubble': return this.renderBubble(item, canvas);
      case 'gauge': return this.renderGauge(item, canvas);
      case 'progressBar': return this.renderProgressBar(item, canvas);
      case 'timeline': return this.renderTimeline(item, canvas);
      default: return null;
    }
  }

  /* ─────────────────────────────────────────────────────────────────
     BAR  (horizontal)
     v2 type: 'horizontalBar'  |  animation easeOutQuart + stagger
     Value label drawn right of each bar via plugin
  ───────────────────────────────────────────────────────────────── */
  private renderBar(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const field = item.yField || '';
    const { labels, values } = this.countData(item, field);
    const bgColors = values.map((_, i) => PALETTE[i % PALETTE.length] + 'cc');
    const bdColors = values.map((_, i) => PALETTE[i % PALETTE.length]);

    return new (Chart as any)(canvas, {
      type: 'horizontalBar',
      data: {
        labels,
        datasets: [{
          label: field || 'Count',
          data: values,
          backgroundColor: bgColors,
          borderColor: bdColors,
          borderWidth: 1.5,
          barPercentage: 0.72,
          categoryPercentage: 0.82
        }]
      },
      options: {
        ...baseOptions(item.name, 'easeOutQuart'),
        scales: {
          xAxes: [linearScale('Count')],
          yAxes: [categoryScale(field)]
        }
      },
      plugins: [valueLabelPlugin(true)]
    });
  }

  /* ─────────────────────────────────────────────────────────────────
     COLUMN  (vertical)
     v2 type: 'bar'  |  easeOutBounce animation
     Value label drawn above each bar via plugin
  ───────────────────────────────────────────────────────────────── */
  private renderColumn(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const field = item.xField || '';
    const { labels, values } = this.countData(item, field);
    const bgColors = values.map((_, i) => PALETTE[i % PALETTE.length] + 'cc');
    const bdColors = values.map((_, i) => PALETTE[i % PALETTE.length]);

    return new (Chart as any)(canvas, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: field || 'Count',
          data: values,
          backgroundColor: bgColors,
          borderColor: bdColors,
          borderWidth: 1.5,
          barPercentage: 0.72,
          categoryPercentage: 0.82
        }]
      },
      options: {
        ...baseOptions(item.name, 'easeOutBounce'),
        scales: {
          xAxes: [categoryScale(field)],
          yAxes: [linearScale('Count')]
        }
      },
      plugins: [valueLabelPlugin(false)]
    });
  }

  /* ─────────────────────────────────────────────────────────────────
     PIE
     animateRotate + animateScale  |  % labels drawn inside slices
     v2 tooltip callback: (tooltipItem, data) not (ctx)
     v2 arc coords: arc._view.startAngle / arc._view.endAngle
  ───────────────────────────────────────────────────────────────── */
  private renderPie(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const { labels, values } = this.xyData(item);
    const total = values.reduce((a, b) => a + b, 0);

    // Plugin: % text inside each slice
    const pieLabelPlugin = {
      id: 'pieLabelPlugin',
      afterDatasetsDraw(chart: any) {
        const { ctx } = chart;
        const meta = chart.getDatasetMeta(0);
        meta.data.forEach((arc: any, i: number) => {
          const pct = total ? ((values[i] / total) * 100).toFixed(1) : '0';
          if (Number(pct) < 4) return;
          const vm = arc._view;                              // v2 model
          const mid = (vm.startAngle + vm.endAngle) / 2;
          const r = (vm.innerRadius + vm.outerRadius) / 2;
          ctx.save();
          ctx.font = `bold 11px ${FONT_FAMILY}`;
          ctx.fillStyle = '#fff';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(`${pct}%`, vm.x + Math.cos(mid) * r, vm.y + Math.sin(mid) * r);
          ctx.restore();
        });
      }
    };

    return new (Chart as any)(canvas, {
      type: 'pie',
      data: {
        labels,
        datasets: [{
          data: values,
          backgroundColor: PALETTE.map(c => c + 'dd'),
          borderColor: '#fff',
          borderWidth: 2.5,
          hoverBorderWidth: 3
        }]
      },
      options: {
        ...baseOptions(item.name),
        animation: { animateRotate: true, animateScale: true, duration: 1000, easing: 'easeOutQuart' },
        legend: buildLegend(true, 'right'),
        tooltips: buildTooltips({
          label: (tooltipItem: any, data: any) => {
            const val = data.datasets[0].data[tooltipItem.index];
            const pct = total ? ((val / total) * 100).toFixed(1) : '0';
            return `  ${data.labels[tooltipItem.index]}: ${val} (${pct}%)`;
          }
        })
      },
      plugins: [pieLabelPlugin]
    });
  }

  /* ─────────────────────────────────────────────────────────────────
     STACKED BAR  (horizontal)
  ───────────────────────────────────────────────────────────────── */
  private renderStackedBar(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const catField = item.yField || '';
    const groupField = item.xField || '';
    const { labels, datasets } = this.stackedData(item, catField, groupField);

    return new (Chart as any)(canvas, {
      type: 'horizontalBar',
      data: { labels, datasets },
      options: {
        ...baseOptions(item.name, 'easeOutQuart'),
        legend: buildLegend(datasets.length > 1),
        scales: {
          xAxes: [linearScale('Count', true)],
          yAxes: [categoryScale(catField, true)]
        }
      }
    });
  }

  /* ─────────────────────────────────────────────────────────────────
     STACKED COLUMN  (vertical)
  ───────────────────────────────────────────────────────────────── */
  private renderStackedColumn(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const catField = item.xField || '';
    const groupField = item.yField || '';
    const { labels, datasets } = this.stackedData(item, catField, groupField);

    return new (Chart as any)(canvas, {
      type: 'bar',
      data: { labels, datasets },
      options: {
        ...baseOptions(item.name, 'easeOutQuart'),
        legend: buildLegend(datasets.length > 1),
        scales: {
          xAxes: [categoryScale(catField, true)],
          yAxes: [linearScale('Count', true)]
        }
      }
    });
  }

  /* ─────────────────────────────────────────────────────────────────
     DOUGHNUT
     cutoutPercentage (v2) not cutout  |  centre total plugin
  ───────────────────────────────────────────────────────────────── */
  private renderDoughnut(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const { labels, values } = this.xyData(item);
    const total = values.reduce((a, b) => a + b, 0);
    const fmt = (n: number) => n >= 1000 ? (n / 1000).toFixed(1) + 'k' : String(n);

    // Plugin: centre total label
    const centreLabelPlugin = {
      id: 'doughnutCentre',
      afterDatasetsDraw(chart: any) {
        const { ctx } = chart;
        const { width, height } = chart.chart;            // v2: chart.chart.*
        const cx = width / 2;
        const cy = height / 2 + 10;
        ctx.save();
        ctx.font = `bold 20px ${FONT_FAMILY}`;
        ctx.fillStyle = COLOR_TITLE;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(fmt(total), cx, cy - 8);
        ctx.font = `11px ${FONT_FAMILY}`;
        ctx.fillStyle = COLOR_LABEL;
        ctx.fillText('Total', cx, cy + 14);
        ctx.restore();
      }
    };

    return new (Chart as any)(canvas, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{
          data: values,
          backgroundColor: PALETTE.map(c => c + 'dd'),
          borderColor: '#fff',
          borderWidth: 3,
          hoverBorderWidth: 3
        }]
      },
      options: {
        ...baseOptions(item.name),
        cutoutPercentage: 62,        // ← v2 (not cutout:'62%')
        animation: { animateRotate: true, animateScale: true, duration: 1100, easing: 'easeOutQuart' },
        legend: buildLegend(true, 'right'),
        tooltips: buildTooltips({
          label: (tooltipItem: any, data: any) => {
            const val = data.datasets[0].data[tooltipItem.index];
            const pct = total ? ((val / total) * 100).toFixed(1) : '0';
            return `  ${data.labels[tooltipItem.index]}: ${val} (${pct}%)`;
          }
        })
      },
      plugins: [centreLabelPlugin]
    });
  }

  /* ─────────────────────────────────────────────────────────────────
     BUBBLE
  ───────────────────────────────────────────────────────────────── */
  private renderBubble(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const xF = item.xField || '';
    const yF = item.yField || '';
    const rF = item.rField || '';

    if (!item.data?.length) {
      return new (Chart as any)(canvas, {
        type: 'bubble',
        data: { datasets: [] },
        options: baseOptions(item.name)
      });
    }

    const rows = item.data.slice(0, 60);
    const bubbleData = rows.map(r => ({
      x: parseFloat(r[xF]) || 0,
      y: parseFloat(r[yF]) || 0,
      r: rF ? Math.min(Math.max(parseFloat(r[rF]) || 8, 4), 30) : 8
    }));

    return new (Chart as any)(canvas, {
      type: 'bubble',
      data: {
        datasets: [{
          label: item.name,
          data: bubbleData,
          backgroundColor: PALETTE.map(c => c + 'aa'),
          borderColor: PALETTE,
          borderWidth: 1.5,
          hoverBorderWidth: 3
        }]
      },
      options: {
        ...baseOptions(item.name, 'easeOutQuart'),
        tooltips: buildTooltips({
          label: (tooltipItem: any, data: any) => {
            const d = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
            return [
              `  X (${xF}): ${d.x}`,
              `  Y (${yF}): ${d.y}`,
              rF ? `  R (${rF}): ${d.r}` : `  Radius: ${d.r}`
            ];
          }
        }),
        scales: {
          xAxes: [linearScale(xF || 'X')],
          yAxes: [linearScale(yF || 'Y')]
        }
      }
    });
  }

  /* ═══════════════════════════════════════════════════════════════════
     GAUGE / SPEEDOMETER
     Pure canvas rAF — no Chart.js version dependency at all.
     Needle swings 0 → target in 1.4 s (easeOutQuart).
     % counter + progress value animate in sync with needle.
  ═══════════════════════════════════════════════════════════════════ */
  private renderGauge(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    const valueField = item.xField || '';
    const targetField = item.yField || '';
    const rows = item.data ?? [];

    let progress = 0;
    let target = 100;
    if (rows.length && valueField)
      progress = rows.reduce((s: number, r: any) => s + (parseFloat(r[valueField]) || 0), 0);
    if (rows.length && targetField)
      target = rows.reduce((s: number, r: any) => s + (parseFloat(r[targetField]) || 0), 0);
    if (target <= 0) target = 100;

    const finalPct = Math.min(Math.max(progress / target, 0), 1);
    let animPct = 0;
    const ANIM_MS = 1400;
    const t0 = performance.now();
    const ease = (t: number) => 1 - Math.pow(1 - t, 4);   // easeOutQuart

    const toRad = (d: number) => (d * Math.PI) / 180;
    const START_DEG = 210;
    const SWEEP_DEG = 210;
    const startAngle = toRad(START_DEG);

    const zones = [
      { from: 0.00, to: 0.25, color: ZONE_COLORS.critical },
      { from: 0.25, to: 0.50, color: ZONE_COLORS.low },
      { from: 0.50, to: 0.75, color: ZONE_COLORS.moderate },
      { from: 0.75, to: 0.90, color: ZONE_COLORS.good },
      { from: 0.90, to: 1.00, color: ZONE_COLORS.excellent },
    ];

    const fmt = (n: number) =>
      n >= 1_000_000 ? (n / 1_000_000).toFixed(1) + 'M'
        : n >= 1000 ? (n / 1000).toFixed(1) + 'k'
          : n % 1 === 0 ? String(Math.round(n))
            : n.toFixed(1);

    const draw = (pct: number) => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      const cx = w / 2;
      const cy = h * 0.58;
      const outerR = Math.min(cx * 0.82, cy * 0.82);
      const trackW = outerR * 0.22;
      const innerR = outerR - trackW;
      const nColor = zoneColor(pct);
      const sLabel = zoneLabel(pct);

      // 1. Track background
      ctx.beginPath();
      ctx.arc(cx, cy, outerR - trackW / 2, startAngle, startAngle + toRad(SWEEP_DEG));
      ctx.strokeStyle = '#e8eaf6';
      ctx.lineWidth = trackW;
      ctx.lineCap = 'butt';
      ctx.stroke();

      // 2. Zone arcs
      zones.forEach(z => {
        const a1 = startAngle + toRad(SWEEP_DEG * z.from);
        const a2 = startAngle + toRad(SWEEP_DEG * z.to);
        ctx.beginPath();
        ctx.arc(cx, cy, outerR - trackW / 2, a1, a2);
        ctx.strokeStyle = z.color + 'aa';
        ctx.lineWidth = trackW;
        ctx.lineCap = 'butt';
        ctx.stroke();
      });

      // 3. Animated progress arc
      if (pct > 0) {
        const progressAngle = startAngle + toRad(SWEEP_DEG * pct);
        const grad = ctx.createLinearGradient(
          cx + Math.cos(startAngle) * outerR, cy + Math.sin(startAngle) * outerR,
          cx + Math.cos(progressAngle) * outerR, cy + Math.sin(progressAngle) * outerR
        );
        grad.addColorStop(0, ZONE_COLORS.critical + 'ff');
        grad.addColorStop(0.5, ZONE_COLORS.moderate + 'ff');
        grad.addColorStop(1, nColor + 'ff');
        ctx.beginPath();
        ctx.arc(cx, cy, outerR - trackW / 2, startAngle, progressAngle);
        ctx.strokeStyle = grad;
        ctx.lineWidth = trackW;
        ctx.lineCap = 'round';
        ctx.stroke();
      }

      // 4. Tick marks + major % labels
      for (let i = 0; i <= 40; i++) {
        const t = i / 40;
        const angle = startAngle + toRad(SWEEP_DEG * t);
        const isMajor = i % 10 === 0;
        const isMid = i % 5 === 0;
        const cos = Math.cos(angle);
        const sin = Math.sin(angle);
        const tOuter = outerR + (isMajor ? 10 : isMid ? 6 : 3);
        ctx.beginPath();
        ctx.moveTo(cx + cos * (outerR + 1), cy + sin * (outerR + 1));
        ctx.lineTo(cx + cos * tOuter, cy + sin * tOuter);
        ctx.strokeStyle = isMajor ? '#455a64' : '#b0bec5';
        ctx.lineWidth = isMajor ? 2 : 1;
        ctx.stroke();
        if (isMajor) {
          ctx.font = `bold 9px ${FONT_FAMILY}`;
          ctx.fillStyle = '#546e7a';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(
            `${Math.round(t * 100)}%`,
            cx + cos * (outerR + 22),
            cy + sin * (outerR + 22)
          );
        }
      }

      // 5. Zone separator lines
      [0.25, 0.50, 0.75, 0.90].forEach(b => {
        const angle = startAngle + toRad(SWEEP_DEG * b);
        ctx.beginPath();
        ctx.moveTo(cx + Math.cos(angle) * (innerR - 2), cy + Math.sin(angle) * (innerR - 2));
        ctx.lineTo(cx + Math.cos(angle) * (outerR + 2), cy + Math.sin(angle) * (outerR + 2));
        ctx.strokeStyle = '#ffffffcc';
        ctx.lineWidth = 2.5;
        ctx.stroke();
      });

      // 6. Needle
      const needleAngle = startAngle + toRad(SWEEP_DEG * pct);
      const needleLength = innerR * 0.88;
      const needleBase = 10;
      const nCos = Math.cos(needleAngle);
      const nSin = Math.sin(needleAngle);
      const pCos = Math.cos(needleAngle + Math.PI / 2);
      const pSin = Math.sin(needleAngle + Math.PI / 2);

      ctx.shadowColor = 'rgba(0,0,0,0.28)';
      ctx.shadowBlur = 10;
      ctx.shadowOffsetX = 2;
      ctx.shadowOffsetY = 3;

      ctx.beginPath();
      ctx.moveTo(cx + nCos * needleLength, cy + nSin * needleLength);
      ctx.lineTo(cx + pCos * needleBase - nCos * 12, cy + pSin * needleBase - nSin * 12);
      ctx.lineTo(cx - nCos * (needleBase * 0.6), cy - nSin * (needleBase * 0.6));
      ctx.lineTo(cx - pCos * needleBase - nCos * 12, cy - pSin * needleBase - nSin * 12);
      ctx.closePath();

      const nGrad = ctx.createLinearGradient(
        cx - nCos * 12, cy - nSin * 12,
        cx + nCos * needleLength, cy + nSin * needleLength
      );
      nGrad.addColorStop(0, '#1a237e');
      nGrad.addColorStop(0.6, nColor);
      nGrad.addColorStop(1, '#ffffff88');
      ctx.fillStyle = nGrad;
      ctx.fill();

      ctx.shadowBlur = 0; ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 0;

      // 7. Hub cap
      ctx.beginPath(); ctx.arc(cx, cy, 16, 0, Math.PI * 2);
      const hub = ctx.createRadialGradient(cx - 3, cy - 3, 2, cx, cy, 16);
      hub.addColorStop(0, '#546e7a'); hub.addColorStop(1, '#1a237e');
      ctx.fillStyle = hub; ctx.fill();
      ctx.beginPath(); ctx.arc(cx, cy, 10, 0, Math.PI * 2);
      ctx.fillStyle = '#eceff1'; ctx.fill();
      ctx.beginPath(); ctx.arc(cx, cy, 4, 0, Math.PI * 2);
      ctx.fillStyle = nColor; ctx.fill();

      // 8. Animated % counter
      const labelY = cy + innerR * 0.38;
      ctx.font = `bold 28px ${FONT_FAMILY}`;
      ctx.fillStyle = nColor;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'alphabetic';
      ctx.fillText(`${(pct * 100).toFixed(1)}%`, cx, labelY);

      // 9. Animated progress / target
      const animProgress = finalPct > 0 ? progress * (pct / finalPct) : 0;
      ctx.font = `12px ${FONT_FAMILY}`;
      ctx.fillStyle = '#546e7a';
      ctx.fillText(`${fmt(animProgress)} / ${fmt(target)}`, cx, labelY + 18);

      // 10. Status badge  (roundRect helper — no ctx.roundRect in v2 browsers)
      const badgeY = labelY + 40;
      ctx.font = `bold 11px ${FONT_FAMILY}`;
      const tw = ctx.measureText(sLabel).width;
      const bx = cx - tw / 2 - 14;
      const by = badgeY - 14;
      const bw = tw + 28;
      const bh = 22;
      roundRect(ctx, bx, by, bw, bh, 11);
      ctx.fillStyle = nColor + '22'; ctx.fill();
      roundRect(ctx, bx, by, bw, bh, 11);
      ctx.strokeStyle = nColor + '88'; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.fillStyle = nColor;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(sLabel, cx, by + bh / 2);

      // 11. Title
      ctx.font = `bold 13px ${FONT_FAMILY}`;
      ctx.fillStyle = COLOR_TITLE;
      ctx.textBaseline = 'top';
      ctx.fillText(item.name, cx, 10);

      // 12. Field subtitle
      if (valueField || targetField) {
        ctx.font = `10px ${FONT_FAMILY}`;
        ctx.fillStyle = COLOR_LABEL;
        ctx.fillText(`${valueField || '—'} ÷ ${targetField || '—'}`, cx, 28);
      }
    };

    // rAF animation loop
    let rafId: number;
    const animate = (now: number) => {
      const t = Math.min((now - t0) / ANIM_MS, 1);
      animPct = ease(t) * finalPct;
      draw(animPct);
      if (t < 1) rafId = requestAnimationFrame(animate);
    };
    rafId = requestAnimationFrame(animate);

    // Minimal Chart-compatible shell
    return {
      destroy: () => cancelAnimationFrame(rafId),
      resize: (w: number, h: number) => {
        canvas.width = w; canvas.height = h;
        canvas.style.width = w + 'px';
        canvas.style.height = h + 'px';
        draw(animPct);
      }
    } as any;
  }

  /* ─────────────────────────────────────────────────────────────────
     PROGRESS BAR
     v2: horizontalBar + stacked xAxes  |  % label plugin using _model
  ───────────────────────────────────────────────────────────────── */
  private renderProgressBar(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const labelField = item.xField || '';
    const completedField = item.yField || '';
    const totalField = item.rField || '';

    if (!item.data?.length) {
      return new (Chart as any)(canvas, {
        type: 'horizontalBar',
        data: { labels: [], datasets: [] },
        options: baseOptions(item.name)
      });
    }

    const rows = item.data.slice(0, 20);
    const labels = rows.map(r => String(r[labelField] ?? ''));
    const completed = rows.map(r => { const v = parseFloat(r[completedField]); return isNaN(v) ? 0 : v; });
    const totals = rows.map(r => { const v = parseFloat(r[totalField]); return isNaN(v) || v <= 0 ? 100 : v; });
    const pcts = completed.map((c, i) => Math.min((c / totals[i]) * 100, 100));
    const remaining = pcts.map(p => Math.max(100 - p, 0));

    const barColors = pcts.map(p =>
      p >= 90 ? '#34a853ee' :
        p >= 75 ? '#fbbc05ee' :
          p >= 50 ? '#ff6d01ee' :
            '#ea4335ee'
    );

    // Plugin: % label right of completed bar (uses _model for v2)
    const pctLabelPlugin = {
      id: 'progressBarLabels',
      afterDatasetsDraw(chart: any) {
        const { ctx } = chart;
        const meta = chart.getDatasetMeta(0);
        if (!meta || !meta.data) return;
        meta.data.forEach((bar: any, i: number) => {
          if (!bar._model) return;
          const fmtN = (n: number) => n >= 1000 ? (n / 1000).toFixed(1) + 'k' : n.toFixed(0);
          ctx.save();
          ctx.font = `bold 11px ${FONT_FAMILY}`;
          ctx.fillStyle = '#1a237e';
          ctx.textAlign = 'left';
          ctx.textBaseline = 'middle';
          ctx.fillText(
            `${pcts[i].toFixed(1)}%  (${fmtN(completed[i])} / ${fmtN(totals[i])})`,
            bar._model.x + 6, bar._model.y
          );
          ctx.restore();
        });
      }
    };

    return new (Chart as any)(canvas, {
      type: 'horizontalBar',
      data: {
        labels,
        datasets: [
          {
            label: 'Completed',
            data: pcts,
            backgroundColor: barColors,
            borderColor: barColors.map((c: string) => c.slice(0, 7)),
            borderWidth: 0,
            barPercentage: 0.65,
            categoryPercentage: 0.85
          },
          {
            label: 'Remaining',
            data: remaining,
            backgroundColor: '#e0e0e055',
            borderColor: '#e0e0e0',
            borderWidth: 0,
            barPercentage: 0.65,
            categoryPercentage: 0.85
          }
        ]
      },
      options: {
        ...baseOptions(item.name, 'easeOutQuart'),
        layout: { padding: { top: 4, right: 120, bottom: 4, left: 4 } },
        legend: buildLegend(false),
        tooltips: buildTooltips({
          label: (tooltipItem: any, data: any) => {
            const i = tooltipItem.index;
            const di = tooltipItem.datasetIndex;
            const fmtN = (n: number) => n >= 1000 ? (n / 1000).toFixed(1) + 'k' : n.toFixed(0);
            return di === 0
              ? `  Completed: ${pcts[i].toFixed(1)}%  (${fmtN(completed[i])} / ${fmtN(totals[i])})`
              : `  Remaining: ${remaining[i].toFixed(1)}%`;
          }
        }),
        scales: {
          xAxes: [{
            stacked: true,
            ticks: {
              min: 0, max: 100, beginAtZero: true,
              fontColor: COLOR_LABEL, fontFamily: FONT_FAMILY, fontSize: 11,
              callback: (v: any) => v + '%'
            },
            gridLines: { color: COLOR_GRID, lineWidth: 1 },
            scaleLabel: {
              display: true, labelString: 'Completion %',
              fontColor: COLOR_TITLE, fontFamily: FONT_FAMILY, fontSize: 12, fontStyle: 'bold'
            }
          }],
          yAxes: [{
            stacked: true,
            ticks: { fontColor: COLOR_LABEL, fontFamily: FONT_FAMILY, fontSize: 11, padding: 4 },
            gridLines: { display: false }
          }]
        }
      },
      plugins: [pctLabelPlugin]
    });
  }

  /* ─────────────────────────────────────────────────────────────────
     TIMELINE
     v2 scatter chart with manual rAF animation.
     scale ids in v2: 'x-axis-0' / 'y-axis-0'.
     Bars draw left→right sequentially (stagger per row).
  ───────────────────────────────────────────────────────────────── */
  private renderTimeline(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const canvasCtx = canvas.getContext('2d');
    if (!canvasCtx) return null;

    const labelField = item.xField || '';
    const startField = item.yField || '';
    const endField = item.rField || '';
    if (!item.data?.length) return null;

    const rows = item.data.slice(0, 20);

    const parseDate = (v: any): number => {
      if (!v) return Date.now();
      if (typeof v === 'number') return v;
      const d = new Date(v);
      return isNaN(d.getTime()) ? Date.now() : d.getTime();
    };

    const events = rows.map((r, i) => ({
      label: String(r[labelField] ?? `Event ${i + 1}`),
      start: parseDate(r[startField]),
      end: parseDate(r[endField] || r[startField]),
      color: PALETTE[i % PALETTE.length]
    }));

    const allTimes = events.flatMap(e => [e.start, e.end]);
    const minTime = Math.min(...allTimes);
    const maxTime = Math.max(...allTimes);
    const timePad = Math.max((maxTime - minTime) * 0.05, 86_400_000);

    const fmtDate = (ms: number) => {
      const d = new Date(ms);
      return `${d.getDate()} ${d.toLocaleString('default', { month: 'short' })} ${d.getFullYear()}`;
    };

    const ANIM_MS = 600;
    const STAGGER_MS = 120;
    const t0 = performance.now();
    const animProgress = new Array(events.length).fill(0);
    const easeIO = (t: number) => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;

    // Plugin: draw timeline bars on top of (invisible) scatter points
    const timelinePlugin = {
      id: 'timelinePlugin',
      afterDatasetsDraw(chart: any) {
        const c = chart.ctx;
        const xScale = chart.scales['x-axis-0'];   // ← v2 scale id
        const yScale = chart.scales['y-axis-0'];
        if (!xScale || !yScale) return;

        events.forEach((ev, i) => {
          const prog = animProgress[i];
          if (prog <= 0) return;

          const x1Full = xScale.getPixelForValue(ev.start);
          const x2Full = xScale.getPixelForValue(Math.max(ev.end, ev.start + timePad * 0.2));
          const y = yScale.getPixelForValue(i);
          const barH = Math.max(14, (yScale.height / Math.max(events.length, 1)) * 0.52);
          const barW = Math.max((x2Full - x1Full) * prog, 8);
          const x2 = x1Full + barW;

          c.save();
          c.shadowColor = 'rgba(0,0,0,0.14)';
          c.shadowBlur = 5;
          c.shadowOffsetY = 2;

          // Rounded bar (manual path — compatible with all browsers)
          const rr = Math.min(barH / 2, 7, barW / 2);
          c.beginPath();
          c.moveTo(x1Full + rr, y - barH / 2);
          c.lineTo(x2 - rr, y - barH / 2);
          c.quadraticCurveTo(x2, y - barH / 2, x2, y - barH / 2 + rr);
          c.lineTo(x2, y + barH / 2 - rr);
          c.quadraticCurveTo(x2, y + barH / 2, x2 - rr, y + barH / 2);
          c.lineTo(x1Full + rr, y + barH / 2);
          c.quadraticCurveTo(x1Full, y + barH / 2, x1Full, y + barH / 2 - rr);
          c.lineTo(x1Full, y - barH / 2 + rr);
          c.quadraticCurveTo(x1Full, y - barH / 2, x1Full + rr, y - barH / 2);
          c.closePath();

          const grad = c.createLinearGradient(x1Full, 0, x2Full, 0);
          grad.addColorStop(0, ev.color + 'ff');
          grad.addColorStop(1, ev.color + '88');
          c.fillStyle = grad;
          c.fill();
          c.shadowBlur = 0;

          // Label fades in when bar > 60% drawn
          if (prog > 0.6) {
            c.font = `bold 11px ${FONT_FAMILY}`;
            const textW = c.measureText(ev.label).width;
            if (barW > textW + 14) {
              c.globalAlpha = Math.min((prog - 0.6) / 0.4, 1);
              c.fillStyle = '#ffffff';
              c.textAlign = 'left';
              c.textBaseline = 'middle';
              c.fillText(ev.label, x1Full + 8, y);
              c.globalAlpha = 1;
            }
          }

          // Duration badge after bar fully drawn
          if (prog >= 1) {
            const days = Math.round((ev.end - ev.start) / 86_400_000);
            if (days > 0) {
              c.font = `10px ${FONT_FAMILY}`;
              c.fillStyle = '#546e7a';
              c.textAlign = 'left';
              c.textBaseline = 'middle';
              c.fillText(`${days}d`, x2Full + 5, y);
            }
          }

          // Start dot
          c.beginPath();
          c.arc(x1Full, y, 4, 0, Math.PI * 2);
          c.fillStyle = '#ffffff'; c.fill();
          c.strokeStyle = ev.color; c.lineWidth = 2; c.stroke();
          c.restore();
        });
      }
    };

    // v2 scatter — xAxes/yAxes style
    const chart = new (Chart as any)(canvas, {
      type: 'scatter',
      data: {
        datasets: events.map(ev => ({
          label: ev.label,
          data: [
            { x: ev.start, y: events.indexOf(ev) },
            { x: ev.end, y: events.indexOf(ev) }
          ],
          pointRadius: 0,
          showLine: false,
          backgroundColor: 'transparent'
        }))
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 0 },      // manual rAF handles animation
        layout: { padding: { top: 8, right: 55, bottom: 8, left: 8 } },
        title: buildTitle(item.name),
        legend: buildLegend(false),
        tooltips: buildTooltips({
          title: (items: any[]) => events[items[0]?.datasetIndex]?.label ?? '',
          label: (tooltipItem: any) => {
            const ev = events[tooltipItem.datasetIndex];
            if (!ev) return '';
            const days = Math.round((ev.end - ev.start) / 86_400_000);
            return [
              `  Start    : ${fmtDate(ev.start)}`,
              `  End      : ${fmtDate(ev.end)}`,
              `  Duration : ${days} day${days !== 1 ? 's' : ''}`
            ];
          }
        }),
        scales: {
          xAxes: [{
            type: 'linear',
            position: 'bottom',
            ticks: {
              min: minTime - timePad,
              max: maxTime + timePad,
              fontColor: COLOR_LABEL, fontFamily: FONT_FAMILY, fontSize: 10,
              maxTicksLimit: 8,
              callback: (v: any) => fmtDate(Number(v))
            },
            gridLines: { color: COLOR_GRID, lineWidth: 1 },
            scaleLabel: {
              display: true, labelString: 'Date',
              fontColor: COLOR_TITLE, fontFamily: FONT_FAMILY, fontSize: 12, fontStyle: 'bold'
            }
          }],
          yAxes: [{
            type: 'linear',
            ticks: {
              min: -0.5,
              max: events.length - 0.5,
              reverse: true,
              fontColor: COLOR_LABEL, fontFamily: FONT_FAMILY, fontSize: 11,
              stepSize: 1,
              callback: (v: any) => events[Math.round(Number(v))]?.label ?? ''
            },
            gridLines: { display: false }
          }]
        }
      },
      plugins: [timelinePlugin]
    });

    // Stagger rAF animation loop
    let rafId: number;
    const animateTimeline = (now: number) => {
      let anyRunning = false;
      events.forEach((_, i) => {
        const barStart = t0 + i * STAGGER_MS;
        const elapsed = now - barStart;
        if (elapsed <= 0) { anyRunning = true; return; }
        const t = Math.min(elapsed / ANIM_MS, 1);
        animProgress[i] = easeIO(t);
        if (t < 1) anyRunning = true;
      });
      chart.update();
      if (anyRunning) rafId = requestAnimationFrame(animateTimeline);
    };
    rafId = requestAnimationFrame(animateTimeline);

    // Patch destroy to cancel rAF
    const origDestroy = chart.destroy.bind(chart);
    chart.destroy = () => { cancelAnimationFrame(rafId); origDestroy(); };

    return chart;
  }

  /* ═══════════════════════════════════════════════════════════════════
     PRIVATE HELPERS
  ═══════════════════════════════════════════════════════════════════ */
  private countData(item: ChartItem, dimField: string) {
    if (!item.data?.length || !dimField) return { labels: [] as string[], values: [] as number[] };
    const counts: Record<string, number> = {};
    for (const row of item.data) {
      const k = String(row[dimField] ?? 'N/A');
      counts[k] = (counts[k] ?? 0) + 1;
    }
    const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 15);
    return { labels: sorted.map(e => e[0]), values: sorted.map(e => e[1]) };
  }

  private xyData(item: ChartItem) {
    if (!item.data?.length) return { labels: [] as string[], values: [] as number[] };
    const xF = item.xField || '';
    const yF = item.yField || '';
    const rows = item.data.slice(0, 20);
    const labels = rows.map(r => String(r[xF] ?? ''));
    const values = rows.map(r => { const v = parseFloat(r[yF]); return isNaN(v) ? 0 : v; });
    return { labels, values };
  }

  private stackedData(item: ChartItem, catField: string, groupField: string) {
    if (!item.data?.length || !catField) return { labels: [] as string[], datasets: [] as any[] };

    const allCats = [...new Set(item.data.map(r => String(r[catField] ?? 'N/A')))].slice(0, 12);

    if (!groupField) {
      return {
        labels: allCats,
        datasets: [{
          label: 'Total',
          data: allCats.map(c => item.data!.filter(r => String(r[catField]) === c).length),
          backgroundColor: PALETTE[0] + 'cc',
          borderColor: PALETTE[0],
          borderWidth: 1,
          barPercentage: 0.75
        }]
      };
    }

    const allGroups = [...new Set(item.data.map(r => String(r[groupField] ?? 'N/A')))].slice(0, 8);
    const datasets = allGroups.map((g, i) => ({
      label: g,
      data: allCats.map(c =>
        item.data!.filter(r => String(r[catField]) === c && String(r[groupField]) === g).length
      ),
      backgroundColor: PALETTE[i % PALETTE.length] + 'cc',
      borderColor: PALETTE[i % PALETTE.length],
      borderWidth: 1,
      barPercentage: 0.8
    }));
    return { labels: allCats, datasets };
  }
}