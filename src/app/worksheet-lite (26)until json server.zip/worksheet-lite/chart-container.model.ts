export interface ChartContainer {
  id?: string;          // c1, c2, c3 ... format
  project_id: number;
  chart_name: string;
  page: string;         // table_name
  fields: {
    x: string;
    y: string;
  };
  x_position: number;
  y_position: number;
  width: number;
  height: number;
}
