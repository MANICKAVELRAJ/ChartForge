// chart-gen.service.ts — ChartItem interface-ல இந்த ஒரு line மட்டும் add பண்ணு

export interface ChartItem {
  id: number;
  containerId?: string;   // ← CHANGE: number → string (c1, c2, c3 format)
  name: string;
  type: string;
  image?: string;
  x?: number;
  y?: number;
  zIndex?: number;
  width?: number;
  height?: number;
  isXYEnabled?: boolean;
  tableId?: number;
  tableName?: string;
  fields?: string[];
  data?: any[];
  valueField?: string;
  xField?: string;
  yField?: string;
  xFieldId?: number;
  yFieldId?: number;
  xFieldValue?: string;
  yFieldValue?: string;
  shortName?: string;
  rField?: string;
}
