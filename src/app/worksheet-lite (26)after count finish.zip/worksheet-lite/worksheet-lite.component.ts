import {
  Component,
  OnInit,
  AfterViewInit,
  HostListener
} from '@angular/core';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { filter, take } from 'rxjs/operators';
import { WorksheetLiteService, PageItem } from './worksheet-lite.service';
import { ChartItem } from './chart-gen.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-worksheet-lite',
  templateUrl: './worksheet-lite.component.html',
  styleUrls: ['./worksheet-lite.component.css']
})
export class WorksheetLiteComponent implements OnInit, AfterViewInit {

  isSidebarCollapsed = false;
  uploadProgress = 0;
  uploadedData: any[] = [];
  defaultWorkflowFields: string[] = [];
  isCustomDataUploaded = false;
  propertyPanelOpen = false;
  selectedItem: ChartItem | null = null;
  editableItem: ChartItem | null = null;
  originalSnapshot: ChartItem | null = null;
  pages: PageItem[] = [];
  pageTableFields: string[] = [];
  filteredFields: any[] = [];
  xFieldDisplayValue = '';
  yFieldDisplayValue = '';
  rFieldDisplayValue = '';
  isXYEnabled = false;
  chartRequirements: any = null;
  isLivePreview = false;
  posSectionOpen = false;

  // ── Value preview ─────────────────────────────────────────────────────
  fieldValueCounts: { label: string; count: number; pct: number }[] = [];
  previewField = '';

  // ── Count Chart: tracks which values are checked ───────────────────────
  countSelectedValues: string[] = [];

  // ── Dashboard stat cards (all chart types) ───────────────────────────
  countCards: { label: string; count: number; tableName: string; field: string; chartId: number }[] = [];

  countCardGradients = [
    'linear-gradient(135deg, #f97316 0%, #fb923c 50%, #fbbf24 100%)',
    'linear-gradient(135deg, #3b82f6 0%, #60a5fa 50%, #38bdf8 100%)',
    'linear-gradient(135deg, #10b981 0%, #34d399 50%, #6ee7b7 100%)',
    'linear-gradient(135deg, #8b5cf6 0%, #a78bfa 50%, #c4b5fd 100%)',
    'linear-gradient(135deg, #ef4444 0%, #f87171 50%, #fca5a5 100%)',
    'linear-gradient(135deg, #ec4899 0%, #f472b6 50%, #f9a8d4 100%)',
  ];

  countCardIcons = ['trending_up', 'people', 'bar_chart', 'insights', 'star', 'bolt'];

  removeCountCard(index: number): void { this.countCards.splice(index, 1); }

  private _wasDragged = false;
  private _moveStartX = 0;
  private _moveStartY = 0;
  private readonly _DRAG_THRESHOLD = 4;

  private resizingIndex: number | null = null;
  private resizeDirection = '';
  private resizeStartX = 0;
  private resizeStartY = 0;
  private resizeStartW = 0;
  private resizeStartH = 0;
  private resizeStartLeft = 0;
  private resizeStartTop = 0;

  readonly MIN_W = 180;
  readonly MIN_H = 140;

  constructor(
    public service: WorksheetLiteService,
    private snackBar: MatSnackBar
  ) { }

  // ══════════════════════════════════════════════════════════════════════
  //  Lifecycle
  // ══════════════════════════════════════════════════════════════════════

  ngOnInit(): void {
    this.service.loadWorkflow();

    this.service.pages$.subscribe(pages => {
      this.pages = pages || [];
      this.pageTableFields = (pages || [])
        .map(p => p.table_name)
        .filter((v, i, a) => a.indexOf(v) === i);
    });

    this.service.data$.subscribe(data => {
      if (Object.keys(data).length > 0) this.updateChartsWithNewData();
    });

    this.service.loadCharts().then(() => {
      this.service.pages$.pipe(
        filter(pages => pages.length > 0), take(1)
      ).subscribe(() => {
        this.service.data$.pipe(
          filter(data => Object.keys(data).length > 0), take(1)
        ).subscribe(() => {
          this.service.loadContainers();
        });
      });
    });
  }

  ngAfterViewInit(): void {
    const canvas = document.querySelector('.worksheet') as HTMLElement;
    if (canvas) this.service.initCanvas(canvas);
  }

  // ══════════════════════════════════════════════════════════════════════
  //  Canvas Drop
  // ══════════════════════════════════════════════════════════════════════

  dropOnCanvas(event: CdkDragDrop<any>): void {
    this.service.dropOnCanvas(event);
    const last = this.service.canvasCharts[this.service.canvasCharts.length - 1];
    if (last) this.refreshGraph(last);
  }

  // ══════════════════════════════════════════════════════════════════════
  //  Drag / Move
  // ══════════════════════════════════════════════════════════════════════

  startMove(event: MouseEvent, index: number): void {
    if ((event.target as HTMLElement).classList.contains('resize-handle')) return;
    this._wasDragged = false;
    this._moveStartX = event.clientX;
    this._moveStartY = event.clientY;
    this.service.startMove(event, index);
  }

  @HostListener('document:mousemove', ['$event'])
  onMouseMove(event: MouseEvent): void {
    if (this.resizingIndex !== null) {
      this._wasDragged = true;
      this.doResize(event);
    } else if (this.service.movingIndex !== null) {
      const dx = Math.abs(event.clientX - this._moveStartX);
      const dy = Math.abs(event.clientY - this._moveStartY);
      if (dx > this._DRAG_THRESHOLD || dy > this._DRAG_THRESHOLD) this._wasDragged = true;
      this.service.moveItem(event);
    }
  }

  @HostListener('document:mouseup')
  onMouseUp(): void {
    if (this.resizingIndex !== null) this.stopResize();
    else this.service.stopMove();
    setTimeout(() => { this._wasDragged = false; }, 0);
  }

  // ══════════════════════════════════════════════════════════════════════
  //  Resize
  // ══════════════════════════════════════════════════════════════════════

  startResize(event: MouseEvent, index: number, direction: string): void {
    event.preventDefault(); event.stopPropagation();
    this._wasDragged = true;
    const c = this.service.canvasCharts[index];
    this.resizingIndex = index;
    this.resizeDirection = direction;
    this.resizeStartX = event.clientX;
    this.resizeStartY = event.clientY;
    this.resizeStartW = c.width ?? this.MIN_W;
    this.resizeStartH = c.height ?? this.MIN_H;
    this.resizeStartLeft = c.x ?? 0;
    this.resizeStartTop = c.y ?? 0;
  }

  private doResize(event: MouseEvent): void {
    if (this.resizingIndex === null) return;
    const c = this.service.canvasCharts[this.resizingIndex];
    const dx = event.clientX - this.resizeStartX;
    const dy = event.clientY - this.resizeStartY;
    const dir = this.resizeDirection;
    let newW = this.resizeStartW, newH = this.resizeStartH;
    let newX = this.resizeStartLeft, newY = this.resizeStartTop;
    if (dir.includes('e')) newW = Math.max(this.MIN_W, this.resizeStartW + dx);
    if (dir.includes('w')) { newX = Math.max(0, this.resizeStartLeft + dx); newW = Math.max(this.MIN_W, this.resizeStartLeft + this.resizeStartW - newX); }
    if (dir.includes('s')) newH = Math.max(this.MIN_H, this.resizeStartH + dy);
    if (dir.includes('n')) { newY = Math.max(0, this.resizeStartTop + dy); newH = Math.max(this.MIN_H, this.resizeStartTop + this.resizeStartH - newY); }
    c.width = Math.round(newW); c.height = Math.round(newH);
    c.x = Math.round(newX); c.y = Math.round(newY);
    this.service.expandCanvas();
    this.service.scheduleUpdate(c);
  }

  private stopResize(): void {
    if (this.resizingIndex !== null) {
      const c = this.service.canvasCharts[this.resizingIndex];
      const idx = this.resizingIndex;
      const [nx, ny] = this.service.findFreePosition(c.x!, c.y!, c.width!, c.height!, idx);
      c.x = nx; c.y = ny;
      this.service.expandCanvas();
      this.service.scheduleUpdate(c);
    }
    this.resizingIndex = null;
    this.resizeDirection = '';
  }

  // ══════════════════════════════════════════════════════════════════════
  //  Property Panel
  // ══════════════════════════════════════════════════════════════════════

  openPropertyPanel(chart: ChartItem): void {
    if (this._wasDragged) return;
    this.isCustomDataUploaded = false;
    this.isXYEnabled = false;
    this.isLivePreview = false;
    this.fieldValueCounts = [];
    this.previewField = '';
    this.countSelectedValues = (chart as any).countSelectedValues ? [...(chart as any).countSelectedValues] : [];
    this.selectedItem = chart;
    this.originalSnapshot = JSON.parse(JSON.stringify(chart));
    this.editableItem = {
      ...chart,
      x: Math.round(chart.x ?? 0),
      y: Math.round(chart.y ?? 0),
      width: Math.round(chart.width ?? this.MIN_W),
      height: Math.round(chart.height ?? this.MIN_H)
    };

    if (this.editableItem.data?.length) {
      this.editableItem.fields = Object.keys(this.editableItem.data[0]);
      this.editableItem.isXYEnabled = true;
      this.xFieldDisplayValue = this.editableItem.xField || '';
      this.yFieldDisplayValue = this.editableItem.yField || '';
      this.rFieldDisplayValue = this.editableItem.rField || '';
      this.isLivePreview = true;
      this.computeFieldValueCounts();
    } else if (this.editableItem.tableId) {
      const page = this.pages.find(p => p.id === this.editableItem!.tableId);
      if (page) {
        const td = this.service.getTableData(page.table_name);
        this.editableItem.data = td;
        this.editableItem.fields = td.length ? Object.keys(td[0]) : [];
        this.editableItem.isXYEnabled = true;
        this.xFieldDisplayValue = this.editableItem.xField || '';
        this.yFieldDisplayValue = this.editableItem.yField || '';
        this.rFieldDisplayValue = this.editableItem.rField || '';
        this.isLivePreview = true;
        this.computeFieldValueCounts();
      }
    } else {
      this.editableItem.fields = [];
      this.filteredFields = [];
      this.xFieldDisplayValue = '';
      this.yFieldDisplayValue = '';
      this.rFieldDisplayValue = '';
    }

    this.editableItem.yField = this.editableItem.yField || '';
    this.editableItem.rField = this.editableItem.rField || '';
    this.chartRequirements = this.service.getChartRequirements(this.editableItem.type);
    this.propertyPanelOpen = true;
  }

  onTableSelect(tableValue: string): void {
    const tableId = +tableValue;
    if (!this.editableItem || !tableId) return;
    const page = this.pages.find(p => p.id == tableId);
    if (!page) return;
    this.editableItem.tableId = +page.id;
    this.editableItem.tableName = page.table_name;
    const tableData = this.service.getTableData(page.table_name);
    this.editableItem.data = tableData;
    this.editableItem.fields = tableData.length ? Object.keys(tableData[0]) : [];
    this.editableItem.isXYEnabled = true;
    this.editableItem.xField = '';
    this.editableItem.yField = '';
    this.editableItem.rField = '';
    this.fieldValueCounts = [];
    this.previewField = '';
    const rowCount = tableData.length;
    this.snackBar.open(
      `📊 "${page.table_name}" — ${rowCount.toLocaleString()} rows loaded`,
      'OK', { duration: 3500 }
    );
    this.chartRequirements = this.service.getChartRequirements(this.editableItem.type);
    this.isLivePreview = true;
    this.refreshGraph(this.editableItem, true);
    this.pushLiveUpdate();
  }

  onXFieldChange(fieldName: string): void {
    if (!this.editableItem) return;
    this.editableItem.xField = fieldName;
    this.xFieldDisplayValue = fieldName;
    this.warnNulls(fieldName);
    this.autoResizeItem(this.editableItem);
    this.computeFieldValueCounts();
    if (this.editableItem.type === 'count') {
      this.countSelectedValues = [];
      (this.editableItem as any).countSelectedValues = [];
    }
    this.pushLiveUpdate();
  }

  onYFieldChange(fieldName: string): void {
    if (!this.editableItem) return;
    this.editableItem.yField = fieldName;
    this.yFieldDisplayValue = fieldName;
    this.warnNulls(fieldName);
    this.autoResizeItem(this.editableItem);
    this.computeFieldValueCounts();
    this.pushLiveUpdate();
  }

  onRFieldChange(fieldName: string): void {
    if (!this.editableItem) return;
    this.editableItem.rField = fieldName;
    this.rFieldDisplayValue = fieldName;
    this.computeFieldValueCounts();
    this.pushLiveUpdate();
  }

  // ══════════════════════════════════════════════════════════════════════
  //  computeFieldValueCounts
  //  Active field (yField for bar, xField otherwise) oda
  //  unique values → count → % — HTML badge list aa show ஆகும்
  // ══════════════════════════════════════════════════════════════════════

  computeFieldValueCounts(): void {
    const req = this.chartRequirements;
    // bar chart: yField is the dimension; others: xField
    const field = (req?.selectableY && !req?.selectableX && this.editableItem?.yField)
      ? this.editableItem.yField
      : (this.editableItem?.xField || this.editableItem?.yField || '');

    this.previewField = field;

    if (!field || !this.editableItem?.data?.length) {
      this.fieldValueCounts = [];
      return;
    }

    const data = this.editableItem.data;
    const counts: Record<string, number> = {};

    for (const row of data) {
      const raw = String(row[field] ?? 'N/A');
      const label = this.service.resolveLabelPublic(raw, field);
      counts[label] = (counts[label] ?? 0) + 1;
    }

    const total = data.length;
    this.fieldValueCounts = Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .map(([label, count]) => ({
        label,
        count,
        pct: Math.round((count / total) * 100)
      }));
  }

  private pushLiveUpdate(): void {
    if (!this.selectedItem || !this.editableItem) return;
    Object.assign(this.selectedItem, {
      type: this.editableItem.type,
      data: this.editableItem.data,
      xField: this.editableItem.xField,
      yField: this.editableItem.yField,
      rField: this.editableItem.rField,
      width: this.editableItem.width,
      height: this.editableItem.height,
      x: this.editableItem.x,
      y: this.editableItem.y,
      countSelectedValues: (this.editableItem as any).countSelectedValues,
    });
  }

  isChartReady(): boolean {
    if (!this.editableItem) return false;
    const req = this.chartRequirements;
    if (!req) return false;
    const xOk = !req.selectableX || !!this.editableItem.xField;
    const yOk = !req.selectableY || !!this.editableItem.yField;
    return !!(this.editableItem.data?.length) && xOk && yOk;
  }

  togglePosSection(): void { this.posSectionOpen = !this.posSectionOpen; }

  checkOverlapLive(item: ChartItem): void {
    if (!item) return;
    const idx = this.service.canvasCharts.findIndex(c => c.id === item.id);
    if (idx === -1) return;
    const [nx, ny] = this.service.findFreePosition(
      item.x ?? 0, item.y ?? 0, item.width ?? 0, item.height ?? 0, idx
    );
    item.x = nx; item.y = ny;
    this.pushLiveUpdate();
    this.service.expandCanvas();
    if (this.selectedItem) this.service.scheduleUpdate(this.selectedItem);
  }

  private warnNulls(field: string): void {
    if (!field || !this.editableItem?.data) return;
    const hasNull = this.editableItem.data.some(
      (d: any) => d[field] === null || d[field] === undefined || d[field] === ''
    );
    if (hasNull) this.snackBar.open(`"${field}" contains null/empty values`, 'Close', { duration: 3000 });
  }

  onSizeChange(): void {
    if (!this.editableItem) return;
    if ((this.editableItem.width ?? 0) < this.MIN_W) this.editableItem.width = this.MIN_W;
    if ((this.editableItem.height ?? 0) < this.MIN_H) this.editableItem.height = this.MIN_H;
    const idx = this.service.canvasCharts.findIndex(c => c.id === this.editableItem!.id);
    if (idx !== -1) {
      const [nx, ny] = this.service.findFreePosition(
        this.editableItem.x ?? 0, this.editableItem.y ?? 0,
        this.editableItem.width ?? this.MIN_W, this.editableItem.height ?? this.MIN_H, idx
      );
      this.editableItem.x = nx; this.editableItem.y = ny;
    }
    this.pushLiveUpdate();
    this.service.expandCanvas();
    if (this.selectedItem) {
      this.selectedItem.width = this.editableItem.width;
      this.selectedItem.height = this.editableItem.height;
      this.selectedItem.x = this.editableItem.x;
      this.selectedItem.y = this.editableItem.y;
      this.service.scheduleUpdate(this.selectedItem);
    }
  }

  refreshGraph(item: ChartItem, autoResize = false): void {
    this.chartRequirements = this.service.getChartRequirements(item.type);
    if (autoResize) this.autoResizeItem(item);
  }

  autoResizeItem(item: ChartItem): void {
    const hasData = !!(item.data?.length);
    const hasField = !!(item.xField || item.yField);
    item.width = hasData && hasField ? 420 : this.MIN_W;
    item.height = hasData && hasField ? 320 : this.MIN_H;
  }

  // ══════════════════════════════════════════════════════════════════════
  //  Save
  // ══════════════════════════════════════════════════════════════════════

  saveChanges(): void {
    if (!this.selectedItem || !this.editableItem) return;
    this.refreshGraph(this.editableItem, false);
    const idx = this.service.canvasCharts.findIndex(c => c.id === this.selectedItem!.id);
    if (idx !== -1) {
      this.service.canvasCharts[idx] = {
        ...this.editableItem,
        containerId: this.service.canvasCharts[idx].containerId
      };
      this.selectedItem = this.service.canvasCharts[idx];
    } else {
      Object.assign(this.selectedItem, this.editableItem);
    }
    this.service.updateContainer(this.selectedItem);
    this.service.expandCanvas();
    this.cleanupPropertyPanel();
  }

  cancelChanges(): void {
    if (this.selectedItem && this.originalSnapshot) {
      const idx = this.service.canvasCharts.findIndex(c => c.id === this.selectedItem!.id);
      if (idx !== -1) this.service.canvasCharts[idx] = { ...this.originalSnapshot };
      else Object.assign(this.selectedItem, this.originalSnapshot);
    }
    this.cleanupPropertyPanel();
  }

  cleanupPropertyPanel(): void {
    this.propertyPanelOpen = false;
    this.selectedItem = null;
    this.editableItem = null;
    this.originalSnapshot = null;
    this.uploadProgress = 0;
    this.isLivePreview = false;
    this.posSectionOpen = false;
    this.fieldValueCounts = [];
    this.previewField = '';
  }

  // ══════════════════════════════════════════════════════════════════════
  //  Remove
  // ══════════════════════════════════════════════════════════════════════

  removeChart(id: number): void {
    this.service.removeChart(id);
    if (this.selectedItem?.id === id) this.cleanupPropertyPanel();
  }

  // ══════════════════════════════════════════════════════════════════════
  //  File Upload
  // ══════════════════════════════════════════════════════════════════════

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files?.length) return;
    const file = input.files[0];
    input.value = '';
    this.uploadProgress = 0;
    this.service.uploadFile(file, p => { this.uploadProgress = p; }).then(data => {
      this.isCustomDataUploaded = true;
      if (this.editableItem) {
        this.editableItem.data = data;
        this.setFieldsForSelectedChart(data);
        this.refreshGraph(this.editableItem, true);
        this.isLivePreview = true;
        this.computeFieldValueCounts();
        this.pushLiveUpdate();
      }
      this.uploadProgress = 100;
      setTimeout(() => { this.uploadProgress = 0; }, 2000);
    });
  }

  setFieldsForSelectedChart(data: any[]): void {
    if (!data?.length || !this.editableItem) return;
    this.editableItem.fields = Object.keys(data[0]);
    this.editableItem.valueField = '';
    this.editableItem.xField = '';
    this.editableItem.yField = '';
    this.editableItem.rField = '';
  }

  clearCustomData(): void {
    if (!this.editableItem) return;
    this.isCustomDataUploaded = false;
    this.editableItem.data = [];
    this.editableItem.fields = [];
    this.editableItem.xField = '';
    this.editableItem.yField = '';
    this.editableItem.rField = '';
    this.isLivePreview = false;
    this.fieldValueCounts = [];
    this.previewField = '';
    this.pushLiveUpdate();
  }

  toggleSidebar(): void { this.isSidebarCollapsed = !this.isSidebarCollapsed; }

  // ══════════════════════════════════════════════════════════════════════
  //  Count Chart — checkbox helpers
  // ══════════════════════════════════════════════════════════════════════

  isCountCardSelected(label: string): boolean {
    if (this.editableItem?.type === 'count') {
      return this.countSelectedValues.includes(label);
    }
    // All other chart types — check dashboard countCards array
    return this.countCards.some(
      c => c.label === label &&
           c.field === this.previewField &&
           c.chartId === this.editableItem?.id
    );
  }

  toggleCountCard(vp: { label: string; count: number; pct: number }, event: Event): void {
    if (!this.editableItem) return;
    const checked   = (event.target as HTMLInputElement).checked;
    const isCount   = this.editableItem.type === 'count';
    const tableName = this.editableItem.tableName || '';
    const field     = this.previewField;
    const chartId   = this.editableItem.id;

    if (isCount) {
      // Count chart — update countSelectedValues → live re-render canvas
      if (checked) {
        if (!this.countSelectedValues.includes(vp.label))
          this.countSelectedValues = [...this.countSelectedValues, vp.label];
      } else {
        this.countSelectedValues = this.countSelectedValues.filter(v => v !== vp.label);
      }
      (this.editableItem as any).countSelectedValues = [...this.countSelectedValues];
      this.pushLiveUpdate();
    } else {
      // All other charts — add/remove from dashboard countCards zone
      if (checked) {
        const exists = this.countCards.some(c => c.label === vp.label && c.field === field && c.chartId === chartId);
        if (!exists) {
          this.countCards.push({ label: vp.label, count: vp.count, tableName, field, chartId });
        }
      } else {
        const idx = this.countCards.findIndex(c => c.label === vp.label && c.field === field && c.chartId === chartId);
        if (idx !== -1) this.countCards.splice(idx, 1);
      }
    }
  }

  // ══════════════════════════════════════════════════════════════════════
  //  updateChartsWithNewData — data.json poll update
  // ══════════════════════════════════════════════════════════════════════

  updateChartsWithNewData(): void {
    this.service.canvasCharts.forEach(chart => {
      if (!chart.tableName) return;
      const nd = this.service.getTableData(chart.tableName);
      if (nd?.length) { chart.data = nd; this.refreshGraph(chart, false); }
    });
    if (this.propertyPanelOpen && this.selectedItem?.tableName && this.editableItem) {
      const nd = this.service.getTableData(this.selectedItem.tableName);
      if (nd?.length) {
        this.editableItem.data = nd;
        this.refreshGraph(this.editableItem, false);
        this.computeFieldValueCounts();
      }
    }
  }
}
