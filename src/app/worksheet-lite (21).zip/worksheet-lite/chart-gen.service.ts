import { Injectable } from '@angular/core';
import {
  Chart,
  registerables,
  ChartConfiguration,
  ChartDataset,
  TooltipItem
} from 'chart.js/auto';

Chart.register(...registerables);

export interface ChartItem {
  id: number;
  name: string;
  type: string;
  image?: string;
  x?: number;
  y?: number;
  zIndex?: number;
  width?: number;
  height?: number;
  isXYEnabled?: boolean;
  tableId?: number;
  tableName?: string;
  fields?: string[];
  data?: any[];
  valueField?: string;
  xField?: string;
  yField?: string;
  xFieldId?: number;
  yFieldId?: number;
  xFieldValue?: string;
  yFieldValue?: string;
  shortName?: string;
  rField?: string;  // ← Bubble chart radius field
}

const FONT_FAMILY = "'Inter', 'Roboto', sans-serif";
const COLOR_TITLE = '#1a237e';
const COLOR_LABEL = '#546e7a';
const COLOR_GRID = '#eceff1';
const COLOR_AXIS = '#90a4ae';

const PALETTE = [
  '#1a73e8', '#34a853', '#fbbc05', '#ea4335',
  '#46bdc6', '#ff6d01', '#673ab7', '#9c27b0',
  '#0097a7', '#795548', '#607d8b'
];

function buildTooltip() {
  return {
    enabled: true,
    backgroundColor: 'rgba(26,35,126,0.92)',
    titleColor: '#fff',
    bodyColor: '#e8eaf6',
    borderColor: '#3949ab',
    borderWidth: 1,
    padding: 10,
    cornerRadius: 8,
    titleFont: { family: FONT_FAMILY, size: 12, weight: 'bold' as const },
    bodyFont: { family: FONT_FAMILY, size: 11 },
    callbacks: {
      label: (ctx: TooltipItem<any>) => {
        const v = ctx.parsed?.y ?? ctx.parsed?.r ?? ctx.formattedValue;
        return `  ${ctx.dataset.label ?? 'Value'}: ${v}`;
      }
    }
  };
}

function buildLegend(show = false) {
  return {
    display: show,
    position: 'top' as const,
    labels: {
      font: { family: FONT_FAMILY, size: 11 },
      color: COLOR_LABEL,
      boxWidth: 12,
      padding: 16,
      usePointStyle: true
    }
  };
}

function buildTitle(text: string) {
  return {
    display: true,
    text,
    color: COLOR_TITLE,
    font: { family: FONT_FAMILY, size: 14, weight: 'bold' as const },
    padding: { top: 8, bottom: 10 }
  };
}

function buildLinearAxis(label: string, stacked = false) {
  return {
    stacked,
    beginAtZero: true,
    border: { color: COLOR_AXIS },
    grid: { color: COLOR_GRID, lineWidth: 1 },
    ticks: {
      color: COLOR_LABEL,
      font: { family: FONT_FAMILY, size: 11 },
      maxTicksLimit: 8,
      padding: 4,
      callback: (v: any) => (Number.isInteger(v) ? v : +v.toFixed(2))
    },
    title: {
      display: !!label,
      text: label,
      color: COLOR_TITLE,
      font: { family: FONT_FAMILY, size: 12, weight: 'bold' as const },
      padding: { top: 4, bottom: 4 }
    }
  };
}

function buildCategoryAxis(label: string, stacked = false) {
  return {
    stacked,
    border: { color: COLOR_AXIS },
    grid: { display: false },
    ticks: {
      color: COLOR_LABEL,
      font: { family: FONT_FAMILY, size: 11 },
      maxRotation: 35,
      minRotation: 0,
      autoSkip: true,
      maxTicksLimit: 12,
      padding: 4
    },
    title: {
      display: !!label,
      text: label,
      color: COLOR_TITLE,
      font: { family: FONT_FAMILY, size: 12, weight: 'bold' as const },
      padding: { top: 4, bottom: 4 }
    }
  };
}

function baseOptions(itemName: string): any {
  return {
    responsive: true,
    maintainAspectRatio: false,
    animation: { duration: 400, easing: 'easeOutQuart' },
    layout: { padding: { top: 4, right: 12, bottom: 4, left: 4 } },
    plugins: {
      title: buildTitle(itemName),
      legend: buildLegend(false),
      tooltip: buildTooltip()
    }
  };
}

@Injectable({ providedIn: 'root' })
export class ChartGenService {

  constructor() { }

  renderChart(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    let cfg: ChartConfiguration;

    switch (item.type) {
      case 'bar': cfg = this.barConfig(item); break;
      case 'column': cfg = this.columnConfig(item); break;
      case 'pie': cfg = this.pieConfig(item); break;
      case 'stackedBar': cfg = this.stackedBarConfig(item); break;
      case 'stackedColumn': cfg = this.stackedColumnConfig(item); break;
      case 'doughnut': cfg = this.doughnutConfig(item); break;
      case 'bubble': cfg = this.bubbleConfig(item); break;  // ← NEW
      case 'gauge': return this.renderGauge(item, canvas);
      case 'progressBar': cfg = this.progressBarConfig(item); break;
      case 'timeline': return this.renderTimeline(item, canvas);
      default: return null;
    }

    return new Chart(ctx, cfg);
  }

  // ─── BAR ────────────────────────────────────────────────────────────
  private barConfig(item: ChartItem): ChartConfiguration {
    const field = item.yField || '';
    const { labels, values } = this.countData(item, field);
    return {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: field || 'Count',
          data: values,
          backgroundColor: PALETTE[0] + 'cc',
          borderColor: PALETTE[0],
          borderWidth: 1,
          borderRadius: { topRight: 5, bottomRight: 5 },
          borderSkipped: 'start',
          barPercentage: 0.7,
          categoryPercentage: 0.8
        }]
      },
      options: {
        ...baseOptions(item.name),
        indexAxis: 'y',
        scales: { x: buildLinearAxis('Count'), y: buildCategoryAxis(field) }
      } as any
    };
  }

  // ─── COLUMN ─────────────────────────────────────────────────────────
  private columnConfig(item: ChartItem): ChartConfiguration {
    const field = item.xField || '';
    const { labels, values } = this.countData(item, field);
    return {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: field || 'Count',
          data: values,
          backgroundColor: PALETTE[0] + 'cc',
          borderColor: PALETTE[0],
          borderWidth: 1,
          borderRadius: { topLeft: 5, topRight: 5 },
          barPercentage: 0.7,
          categoryPercentage: 0.8
        }]
      },
      options: {
        ...baseOptions(item.name),
        scales: { x: buildCategoryAxis(field), y: buildLinearAxis('Count') }
      } as any
    };
  }

  // ─── PIE ────────────────────────────────────────────────────────────
  private pieConfig(item: ChartItem): ChartConfiguration {
    const { labels, values } = this.xyData(item);
    return {
      type: 'pie',
      data: {
        labels,
        datasets: [{
          data: values,
          backgroundColor: PALETTE.map(c => c + 'dd'),
          borderColor: '#fff',
          borderWidth: 2,
          hoverOffset: 6
        }]
      },
      options: {
        ...baseOptions(item.name),
        plugins: {
          title: buildTitle(item.name),
          legend: {
            display: true, position: 'right' as const,
            labels: {
              font: { family: FONT_FAMILY, size: 11 }, color: COLOR_LABEL,
              boxWidth: 12, padding: 10, usePointStyle: true
            }
          },
          tooltip: {
            ...buildTooltip(), callbacks: {
              label: (ctx: TooltipItem<'pie'>) => {
                const total = (ctx.dataset.data as number[]).reduce((a, b) => a + b, 0);
                const pct = total ? ((ctx.parsed / total) * 100).toFixed(1) : '0';
                return `  ${ctx.label}: ${ctx.parsed} (${pct}%)`;
              }
            }
          }
        }
      } as any
    };
  }

  // ─── STACKED BAR ────────────────────────────────────────────────────
  private stackedBarConfig(item: ChartItem): ChartConfiguration {
    const catField = item.yField || '';
    const groupField = item.xField || '';
    const { labels, datasets } = this.stackedData(item, catField, groupField);
    return {
      type: 'bar',
      data: { labels, datasets },
      options: {
        ...baseOptions(item.name),
        indexAxis: 'y',
        plugins: { ...baseOptions(item.name).plugins, legend: buildLegend(datasets.length > 1) },
        scales: {
          x: { ...buildLinearAxis('Count'), stacked: true },
          y: { ...buildCategoryAxis(catField), stacked: true }
        }
      } as any
    };
  }

  // ─── STACKED COLUMN ─────────────────────────────────────────────────
  private stackedColumnConfig(item: ChartItem): ChartConfiguration {
    const catField = item.xField || '';
    const groupField = item.yField || '';
    const { labels, datasets } = this.stackedData(item, catField, groupField);
    return {
      type: 'bar',
      data: { labels, datasets },
      options: {
        ...baseOptions(item.name),
        indexAxis: 'x',
        plugins: { ...baseOptions(item.name).plugins, legend: buildLegend(datasets.length > 1) },
        scales: {
          x: { ...buildCategoryAxis(catField), stacked: true },
          y: { ...buildLinearAxis('Count'), stacked: true }
        }
      } as any
    };
  }

  // ─── DOUGHNUT ───────────────────────────────────────────────────────
  private doughnutConfig(item: ChartItem): ChartConfiguration {
    const { labels, values } = this.xyData(item);
    return {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{
          data: values,
          backgroundColor: PALETTE.map(c => c + 'dd'),
          borderColor: '#fff',
          borderWidth: 2,
          hoverOffset: 8
        }]
      },
      options: {
        ...baseOptions(item.name),
        cutout: '60%',
        plugins: {
          title: buildTitle(item.name),
          legend: {
            display: true, position: 'right' as const,
            labels: {
              font: { family: FONT_FAMILY, size: 11 }, color: COLOR_LABEL,
              boxWidth: 12, padding: 10, usePointStyle: true
            }
          },
          tooltip: {
            ...buildTooltip(), callbacks: {
              label: (ctx: TooltipItem<'doughnut'>) => {
                const total = (ctx.dataset.data as number[]).reduce((a, b) => a + b, 0);
                const pct = total ? ((ctx.parsed / total) * 100).toFixed(1) : '0';
                return `  ${ctx.label}: ${ctx.parsed} (${pct}%)`;
              }
            }
          }
        }
      } as any
    };
  }

  // ─── BUBBLE ─────────────────────────────────────────────────────── NEW
  private bubbleConfig(item: ChartItem): ChartConfiguration {
    const xF = item.xField || '';
    const yF = item.yField || '';
    const rF = item.rField || '';   // radius field

    if (!item.data?.length) {
      return { type: 'bubble', data: { datasets: [] }, options: baseOptions(item.name) };
    }

    const rows = item.data.slice(0, 50);

    // If rField is set use it, else default radius = 8
    const bubbleData = rows.map(r => ({
      x: parseFloat(r[xF]) || 0,
      y: parseFloat(r[yF]) || 0,
      r: rF ? Math.min(Math.max(parseFloat(r[rF]) || 8, 4), 30) : 8
    }));

    return {
      type: 'bubble',
      data: {
        datasets: [{
          label: item.name,
          data: bubbleData,
          backgroundColor: PALETTE.map(c => c + '99'),   // semi-transparent
          borderColor: PALETTE,
          borderWidth: 1.5,
          hoverBorderWidth: 2.5
        }]
      },
      options: {
        ...baseOptions(item.name),
        plugins: {
          title: buildTitle(item.name),
          legend: buildLegend(false),
          tooltip: {
            ...buildTooltip(),
            callbacks: {
              label: (ctx: TooltipItem<'bubble'>) => {
                const d = ctx.raw as { x: number; y: number; r: number };
                return [
                  `  X (${xF}): ${d.x}`,
                  `  Y (${yF}): ${d.y}`,
                  rF ? `  R (${rF}): ${d.r}` : `  Radius: ${d.r}`
                ];
              }
            }
          }
        },
        scales: {
          x: buildLinearAxis(xF || 'X'),
          y: buildLinearAxis(yF || 'Y')
        }
      } as any
    };
  }

  // ─── GAUGE / SPEEDOMETER ────────────────────────────────────────────
  private renderGauge(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    const valueField = item.xField || '';
    const targetField = item.yField || '';
    const rows = item.data ?? [];

    // Sum all progress & target rows
    let progress = 0;
    let target = 100;
    if (rows.length && valueField) progress = rows.reduce((s: number, r: any) => s + (parseFloat(r[valueField]) || 0), 0);
    if (rows.length && targetField) target = rows.reduce((s: number, r: any) => s + (parseFloat(r[targetField]) || 0), 0);
    if (target <= 0) target = 100;

    const pct = Math.min(Math.max(progress / target, 0), 1);  // clamp 0–1

    // Colour zones: red < 50%, orange 50–75%, yellow 75–90%, green ≥ 90%
    const zoneColor =
      pct >= 0.90 ? '#34a853' :
        pct >= 0.75 ? '#fbbc05' :
          pct >= 0.50 ? '#ff6d01' :
            '#ea4335';

    // ── needle plugin ──────────────────────────────────────────────────
    const gaugeNeedle = {
      id: 'gaugeNeedle',
      afterDatasetsDraw(chart: any) {
        const { ctx: c, chartArea } = chart;
        if (!chartArea) return;

        const cx = chart.getDatasetMeta(0).data[0]?.x ?? (chartArea.left + chartArea.right) / 2;
        const cy = chart.getDatasetMeta(0).data[0]?.y ?? (chartArea.top + chartArea.bottom) / 2;

        // Arc spans -180° → 0° (left to right half circle)
        // pct=0 → needle at -180° (left), pct=1 → needle at 0° (right)
        const angle = Math.PI * (1 + pct);   // π (left) … 2π (right)

        const outerR = (chart.getDatasetMeta(0).data[0] as any)?._model?.outerRadius
          ?? chart.getDatasetMeta(0).data[0]?.outerRadius
          ?? 90;
        const needleLen = outerR * 0.82;

        c.save();

        // ── Needle shadow
        c.shadowColor = 'rgba(0,0,0,0.18)';
        c.shadowBlur = 4;

        // ── Needle line
        c.beginPath();
        c.moveTo(cx, cy);
        c.lineTo(
          cx + Math.cos(angle) * needleLen,
          cy + Math.sin(angle) * needleLen
        );
        c.strokeStyle = '#1a237e';
        c.lineWidth = 3.5;
        c.lineCap = 'round';
        c.stroke();

        c.shadowBlur = 0;

        // ── Hub circle
        c.beginPath();
        c.arc(cx, cy, 8, 0, Math.PI * 2);
        c.fillStyle = '#1a237e';
        c.fill();
        c.beginPath();
        c.arc(cx, cy, 4, 0, Math.PI * 2);
        c.fillStyle = '#ffffff';
        c.fill();

        // ── Centre label — percent
        c.font = `bold 18px 'Inter','Roboto',sans-serif`;
        c.fillStyle = zoneColor;
        c.textAlign = 'center';
        c.textBaseline = 'bottom';
        c.fillText(`${(pct * 100).toFixed(1)}%`, cx, cy - 14);

        // ── Centre label — progress / target
        c.font = `12px 'Inter','Roboto',sans-serif`;
        c.fillStyle = '#546e7a';
        c.textBaseline = 'top';
        const fmt = (n: number) => n >= 1000 ? (n / 1000).toFixed(1) + 'k' : String(n);
        c.fillText(`${fmt(progress)} / ${fmt(target)}`, cx, cy + 16);

        // ── Zone tick marks (0%, 25%, 50%, 75%, 100%)
        const innerR = outerR * 0.72;
        const tickR = outerR * 1.05;
        [0, 0.25, 0.5, 0.75, 1].forEach(t => {
          const a = Math.PI * (1 + t);
          c.beginPath();
          c.moveTo(cx + Math.cos(a) * innerR, cy + Math.sin(a) * innerR);
          c.lineTo(cx + Math.cos(a) * tickR, cy + Math.sin(a) * tickR);
          c.strokeStyle = '#90a4ae';
          c.lineWidth = 1.5;
          c.stroke();

          // Tick label
          const labelR = outerR * 1.18;
          c.font = `10px 'Inter',sans-serif`;
          c.fillStyle = '#90a4ae';
          c.textAlign = 'center';
          c.textBaseline = 'middle';
          c.fillText(`${t * 100}%`,
            cx + Math.cos(a) * labelR,
            cy + Math.sin(a) * labelR
          );
        });

        c.restore();
      }
    };

    // ── Chart.js doughnut — half circle ───────────────────────────────
    // segments: filled arc, remaining arc, hidden lower half
    const filled = pct * 180;
    const remaining = (1 - pct) * 180;

    return new Chart(ctx, {
      type: 'doughnut',
      data: {
        datasets: [{
          data: [filled, remaining, 180],
          backgroundColor: [zoneColor + 'ee', '#e0e0e044', 'transparent'],
          borderWidth: [0, 0, 0],
          hoverOffset: 0
        } as any]
      },
      options: {
        rotation: -90,
        circumference: 180,
        responsive: true,
        maintainAspectRatio: false,
        cutout: '68%',
        animation: { duration: 700, easing: 'easeOutQuart' },
        layout: { padding: { top: 8, right: 20, bottom: 0, left: 20 } },
        plugins: {
          title: {
            display: true,
            text: item.name,
            color: '#1a237e',
            font: { family: "'Inter','Roboto',sans-serif", size: 14, weight: 'bold' as const },
            padding: { top: 6, bottom: 6 }
          },
          legend: { display: false },
          tooltip: { enabled: false }
        }
      } as any,
      plugins: [gaugeNeedle]
    } as any);
  }

  // ─── PROGRESS BAR – Completion Status ──────────────────────────────
  private progressBarConfig(item: ChartItem): ChartConfiguration {
    const labelField = item.xField || '';   // task / category label
    const completedField = item.yField || '';  // completed / achieved value
    const totalField = item.rField || '';   // total / target value

    if (!item.data?.length) {
      return {
        type: 'bar',
        data: { labels: [], datasets: [] },
        options: { ...baseOptions(item.name), indexAxis: 'y' } as any
      };
    }

    const rows = item.data.slice(0, 20);

    // Build per-row labels and values
    const labels = rows.map(r => String(r[labelField] ?? ''));
    const completed = rows.map(r => {
      const v = parseFloat(r[completedField]);
      return isNaN(v) ? 0 : v;
    });
    const totals = rows.map(r => {
      const v = parseFloat(r[totalField]);
      return isNaN(v) || v <= 0 ? 100 : v;
    });

    // Percentage done per row
    const pcts = completed.map((c, i) => Math.min((c / totals[i]) * 100, 100));
    const remaining = pcts.map(p => Math.max(100 - p, 0));

    // Per-bar colours based on % completion
    const barColors = pcts.map(p =>
      p >= 90 ? '#34a853ee' :
        p >= 75 ? '#fbbc05ee' :
          p >= 50 ? '#ff6d01ee' :
            '#ea4335ee'
    );

    // ── percent label plugin ─────────────────────────────────────────
    const pctLabelPlugin = {
      id: 'progressBarLabels',
      afterDatasetsDraw(chart: any) {
        const { ctx } = chart;
        chart.getDatasetMeta(0).data.forEach((bar: any, i: number) => {
          const pct = pcts[i];
          const comp = completed[i];
          const tot = totals[i];
          const fmt = (n: number) => n >= 1000 ? (n / 1000).toFixed(1) + 'k' : n.toFixed(0);

          ctx.save();
          ctx.font = `bold 11px 'Inter','Roboto',sans-serif`;
          ctx.fillStyle = '#1a237e';
          ctx.textAlign = 'left';
          ctx.textBaseline = 'middle';

          // Percentage badge after the bar
          const x = bar.x + 6;
          const y = bar.y;
          ctx.fillText(`${pct.toFixed(1)}%  (${fmt(comp)} / ${fmt(tot)})`, x, y);
          ctx.restore();
        });
      }
    };

    return {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            // Completed segment
            label: 'Completed',
            data: pcts,
            backgroundColor: barColors,
            borderColor: barColors.map(c => c.slice(0, 7)),
            borderWidth: 0,
            borderRadius: { topRight: 6, bottomRight: 6 },
            borderSkipped: false,
            barPercentage: 0.65,
            categoryPercentage: 0.85
          },
          {
            // Remaining segment
            label: 'Remaining',
            data: remaining,
            backgroundColor: '#e0e0e055',
            borderColor: '#e0e0e0',
            borderWidth: 0,
            borderRadius: { topRight: 6, bottomRight: 6 },
            borderSkipped: false,
            barPercentage: 0.65,
            categoryPercentage: 0.85
          }
        ]
      },
      options: {
        ...baseOptions(item.name),
        indexAxis: 'y',
        layout: { padding: { top: 4, right: 120, bottom: 4, left: 4 } },
        plugins: {
          title: buildTitle(item.name),
          legend: { display: false },
          tooltip: {
            enabled: true,
            backgroundColor: 'rgba(26,35,126,0.92)',
            titleColor: '#fff',
            bodyColor: '#e8eaf6',
            borderColor: '#3949ab',
            borderWidth: 1,
            padding: 10,
            cornerRadius: 8,
            callbacks: {
              label: (ctx: TooltipItem<any>) => {
                const i = ctx.dataIndex;
                if (ctx.datasetIndex === 0) {
                  return `  Completed: ${pcts[i].toFixed(1)}%  (${completed[i]} / ${totals[i]})`;
                }
                return `  Remaining: ${remaining[i].toFixed(1)}%`;
              }
            }
          }
        },
        scales: {
          x: {
            stacked: true,
            min: 0,
            max: 100,
            beginAtZero: true,
            border: { color: COLOR_AXIS },
            grid: { color: COLOR_GRID, lineWidth: 1 },
            ticks: {
              color: COLOR_LABEL,
              font: { family: FONT_FAMILY, size: 11 },
              callback: (v: any) => v + '%'
            },
            title: {
              display: true,
              text: 'Completion %',
              color: COLOR_TITLE,
              font: { family: FONT_FAMILY, size: 12, weight: 'bold' as const }
            }
          },
          y: {
            stacked: true,
            border: { color: COLOR_AXIS },
            grid: { display: false },
            ticks: {
              color: COLOR_LABEL,
              font: { family: FONT_FAMILY, size: 11 },
              padding: 4
            }
          }
        }
      } as any,
      plugins: [pctLabelPlugin]
    } as any;
  }

  // ─── TIMELINE – Events over time ────────────────────────────────────
  private renderTimeline(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    const labelField = item.xField || '';  // event / task name
    const startField = item.yField || '';  // start date
    const endField = item.rField || '';  // end date

    if (!item.data?.length) return null;

    const rows = item.data.slice(0, 20);

    // ── Parse date robustly (string "2024-01-01", timestamp, number) ──
    const parseDate = (v: any): number => {
      if (!v) return Date.now();
      if (typeof v === 'number') return v;
      const d = new Date(v);
      return isNaN(d.getTime()) ? Date.now() : d.getTime();
    };

    const events = rows.map((r, i) => ({
      label: String(r[labelField] ?? `Event ${i + 1}`),
      start: parseDate(r[startField]),
      end: parseDate(r[endField] || r[startField]),
      color: PALETTE[i % PALETTE.length]
    }));

    // Global x-axis range with padding
    const allTimes = events.flatMap(e => [e.start, e.end]);
    const minTime = Math.min(...allTimes);
    const maxTime = Math.max(...allTimes);
    const padding = Math.max((maxTime - minTime) * 0.05, 86400000); // 5% or 1 day min

    // ── Date formatter ───────────────────────────────────────────────
    const fmtDate = (ms: number) => {
      const d = new Date(ms);
      return `${d.getDate()} ${d.toLocaleString('default', { month: 'short' })} ${d.getFullYear()}`;
    };

    // ── Custom canvas plugin — draws bars + labels ───────────────────
    const timelinePlugin = {
      id: 'timelinePlugin',
      afterDatasetsDraw(chart: any) {
        const { ctx: c, chartArea, scales } = chart;
        if (!chartArea || !scales?.x || !scales?.y) return;

        const xScale = scales.x;
        const yScale = scales.y;

        events.forEach((ev, i) => {
          const x1 = xScale.getPixelForValue(ev.start);
          const x2 = xScale.getPixelForValue(Math.max(ev.end, ev.start + padding * 0.2));
          const y = yScale.getPixelForValue(i);
          const barH = Math.max(14, (yScale.height / Math.max(events.length, 1)) * 0.52);
          const barW = Math.max(x2 - x1, 8);
          const r = Math.min(barH / 2, 7);

          c.save();

          // Drop shadow
          c.shadowColor = 'rgba(0,0,0,0.14)';
          c.shadowBlur = 5;
          c.shadowOffsetY = 2;

          // Rounded rect
          c.beginPath();
          c.moveTo(x1 + r, y - barH / 2);
          c.lineTo(x2 - r, y - barH / 2);
          c.quadraticCurveTo(x2, y - barH / 2, x2, y - barH / 2 + r);
          c.lineTo(x2, y + barH / 2 - r);
          c.quadraticCurveTo(x2, y + barH / 2, x2 - r, y + barH / 2);
          c.lineTo(x1 + r, y + barH / 2);
          c.quadraticCurveTo(x1, y + barH / 2, x1, y + barH / 2 - r);
          c.lineTo(x1, y - barH / 2 + r);
          c.quadraticCurveTo(x1, y - barH / 2, x1 + r, y - barH / 2);
          c.closePath();

          // Horizontal gradient fill
          const grad = c.createLinearGradient(x1, 0, x2, 0);
          grad.addColorStop(0, ev.color + 'ff');
          grad.addColorStop(1, ev.color + '88');
          c.fillStyle = grad;
          c.fill();
          c.shadowBlur = 0;

          // Event label inside bar (only if wide enough)
          c.font = `bold 11px 'Inter','Roboto',sans-serif`;
          const textW = c.measureText(ev.label).width;
          if (barW > textW + 14) {
            c.fillStyle = '#ffffff';
            c.textAlign = 'left';
            c.textBaseline = 'middle';
            c.fillText(ev.label, x1 + 8, y);
          }

          // Duration badge right of bar
          const days = Math.round((ev.end - ev.start) / 86400000);
          if (days > 0) {
            c.font = `10px 'Inter',sans-serif`;
            c.fillStyle = '#546e7a';
            c.textAlign = 'left';
            c.textBaseline = 'middle';
            c.fillText(`${days}d`, x2 + 5, y);
          }

          // Start dot
          c.beginPath();
          c.arc(x1, y, 4, 0, Math.PI * 2);
          c.fillStyle = '#ffffff';
          c.fill();
          c.strokeStyle = ev.color;
          c.lineWidth = 2;
          c.stroke();

          c.restore();
        });
      }
    };

    // Scatter chart — invisible points, plugin draws bars
    return new Chart(ctx, {
      type: 'scatter',
      data: {
        datasets: events.map((ev, i) => ({
          label: ev.label,
          data: [{ x: ev.start, y: i }, { x: ev.end, y: i }],
          pointRadius: 0,
          showLine: false,
          backgroundColor: 'transparent'
        }))
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 500, easing: 'easeOutQuart' },
        layout: { padding: { top: 8, right: 55, bottom: 8, left: 8 } },
        plugins: {
          title: {
            display: true,
            text: item.name,
            color: COLOR_TITLE,
            font: { family: FONT_FAMILY, size: 14, weight: 'bold' as const },
            padding: { top: 6, bottom: 10 }
          },
          legend: { display: false },
          tooltip: {
            enabled: true,
            backgroundColor: 'rgba(26,35,126,0.92)',
            titleColor: '#fff',
            bodyColor: '#e8eaf6',
            borderColor: '#3949ab',
            borderWidth: 1,
            padding: 10,
            cornerRadius: 8,
            callbacks: {
              title: (items: any[]) => events[items[0]?.datasetIndex]?.label ?? '',
              label: (ctx: any) => {
                const ev = events[ctx.datasetIndex];
                if (!ev) return '';
                const days = Math.round((ev.end - ev.start) / 86400000);
                return [
                  `  Start    : ${fmtDate(ev.start)}`,
                  `  End      : ${fmtDate(ev.end)}`,
                  `  Duration : ${days} day${days !== 1 ? 's' : ''}`
                ];
              }
            }
          }
        },
        scales: {
          x: {
            type: 'linear',
            min: minTime - padding,
            max: maxTime + padding,
            border: { color: COLOR_AXIS },
            grid: { color: COLOR_GRID, lineWidth: 1 },
            ticks: {
              color: COLOR_LABEL,
              font: { family: FONT_FAMILY, size: 10 },
              maxTicksLimit: 8,
              callback: (v: any) => fmtDate(Number(v))
            },
            title: {
              display: true,
              text: 'Date',
              color: COLOR_TITLE,
              font: { family: FONT_FAMILY, size: 12, weight: 'bold' as const }
            }
          },
          y: {
            type: 'linear',
            min: -0.5,
            max: events.length - 0.5,
            reverse: true,
            border: { color: COLOR_AXIS },
            grid: { display: false },
            ticks: {
              color: COLOR_LABEL,
              font: { family: FONT_FAMILY, size: 11 },
              stepSize: 1,
              callback: (v: any) => {
                const idx = Math.round(Number(v));
                return events[idx]?.label ?? '';
              }
            }
          }
        }
      } as any,
      plugins: [timelinePlugin]
    } as any);
  }

  // ─── HELPERS ────────────────────────────────────────────────────────
  private countData(item: ChartItem, dimField: string) {
    if (!item.data?.length || !dimField) return { labels: [], values: [] };
    const counts: Record<string, number> = {};
    for (const row of item.data) {
      const k = String(row[dimField] ?? 'N/A');
      counts[k] = (counts[k] ?? 0) + 1;
    }
    const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 15);
    return { labels: sorted.map(e => e[0]), values: sorted.map(e => e[1]) };
  }

  private xyData(item: ChartItem) {
    if (!item.data?.length) return { labels: [], values: [] };
    const xF = item.xField || '';
    const yF = item.yField || '';
    const rows = item.data.slice(0, 20);
    const labels = rows.map(r => String(r[xF] ?? ''));
    const values = rows.map(r => { const v = parseFloat(r[yF]); return isNaN(v) ? 0 : v; });
    return { labels, values };
  }

  private stackedData(item: ChartItem, catField: string, groupField: string) {
    if (!item.data?.length || !catField) return { labels: [], datasets: [] };
    const allCats = [...new Set(item.data.map(r => String(r[catField] ?? 'N/A')))].slice(0, 12);
    if (!groupField) {
      return {
        labels: allCats,
        datasets: [{
          label: 'Total',
          data: allCats.map(c => item.data!.filter(r => String(r[catField]) === c).length),
          backgroundColor: PALETTE[0] + 'cc',
          borderColor: PALETTE[0],
          borderWidth: 1,
          borderRadius: 4,
          barPercentage: 0.75
        }]
      };
    }
    const allGroups = [...new Set(item.data.map(r => String(r[groupField] ?? 'N/A')))].slice(0, 8);
    const datasets: ChartDataset[] = allGroups.map((g, i) => ({
      label: g,
      data: allCats.map(c =>
        item.data!.filter(r => String(r[catField]) === c && String(r[groupField]) === g).length
      ),
      backgroundColor: PALETTE[i % PALETTE.length] + 'cc',
      borderColor: PALETTE[i % PALETTE.length],
      borderWidth: 1,
      borderRadius: 3,
      barPercentage: 0.8
    } as any));
    return { labels: allCats, datasets };
  }
}